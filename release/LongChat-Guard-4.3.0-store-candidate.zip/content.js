(function(){"use strict";const Pe={minimumGrowthSamples:3,failureQuantile:.2,growthReserveQuantile:.8};function ke(e){const t=e.samples.filter(u=>u.highestConfirmedSafeLoad!==void 0&&u.parserHealth==="healthy"&&u.coverageState==="complete"),n=t.length?Math.max(...t.map(u=>u.highestConfirmedSafeLoad)):void 0,o=e.samples.filter(u=>u.empiricalFailureLoad!==void 0&&u.failureReferenceQuality==="strong"),a=e.samples.filter(u=>u.empiricalFailureLoad!==void 0&&u.failureReferenceQuality==="conservative"),i=e.samples.filter(u=>u.empiricalFailureLoad!==void 0&&u.failureReferenceQuality==="provisional"),r=o.length>0?o:a.length>0?a:[],l=r.length>0?{load:yt(r.map(u=>u.empiricalFailureLoad),Pe.failureQuantile),quality:o.length>0?"strong":"conservative",sourceConversationCount:r.length}:void 0,S=i.length>0?yt(i.map(u=>u.empiricalFailureLoad),Pe.failureQuantile):void 0,b=e.turnGrowthSamples.filter(u=>!u.uncertain&&Number.isFinite(u.delta)&&u.delta>0),v=b.length>=Pe.minimumGrowthSamples,f=b.length>0?ln(b.map(u=>u.delta),Pe.growthReserveQuantile):0;return{...n!==void 0?{safeEvidenceLoad:n}:{},...l?{failureReference:l}:{},...S!==void 0?{provisionalFailureReference:S}:{},growthReserve:Math.max(0,Math.round(f)),growthReserveReady:v,confirmedSafeConversations:t.length,confirmedFailureConversations:o.length+a.length}}function yt(e,t){if(e.length===0)return 0;const n=[...e].sort((a,i)=>a-i),o=Math.max(1,Math.ceil(Ct(t,0,1)*n.length));return n[Math.min(n.length-1,o-1)]??0}function ln(e,t){if(e.length===0)return 0;const n=[...e].sort((a,i)=>a-i),o=Math.max(1,Math.ceil(Ct(t,0,1)*n.length));return n[Math.min(n.length-1,o-1)]??0}function Ct(e,t,n){return Math.max(t,Math.min(n,e))}const dn=[/maximum length for this conversation/i,/maximum conversation length/i,/会话.{0,12}(?:最大长度|长度上限|过长)/i,/对话.{0,12}(?:最大长度|长度上限|过长)/i],un=[/conversation.{0,30}(?:too long|length limit|limit)/i,/maximum.{0,12}length/i];function Ye(e){const t=e.trim();return t?dn.some(n=>n.test(t))?{kind:"conversation_length_limit",confidence:"high"}:un.some(n=>n.test(t))?{kind:"conversation_length_limit",confidence:"medium"}:/rate limit|too many requests/i.test(t)?{kind:"rate_limit",confidence:"high"}:/network|connection|网络|连接失败/i.test(t)?{kind:"network_error",confidence:"medium"}:/upload|file|文件|上传/i.test(t)?{kind:"file_error",confidence:"medium"}:/usage limit|message limit|messages? remaining|额度|消息.*上限/i.test(t)?{kind:"model_usage_limit",confidence:"medium"}:/sign in|unauthorized|authentication|登录|认证/i.test(t)?{kind:"auth_error",confidence:"medium"}:{kind:"unknown",confidence:"low"}:{kind:"unknown",confidence:"low"}}const hn="lcg:",gn=/^lcg:[0-9a-f]{64}$/;function mn(e){return gn.test(e)}async function pn(e,t){if(mn(e))return e;const o=await new kt(t).fingerprint(`conversation${e}`);return`${hn}${o}`}class kt{constructor(t){this.installSalt=t}installSalt;async fingerprint(t){const n=new TextEncoder().encode(`${this.installSalt}${t}`),o=await crypto.subtle.digest("SHA-256",n);return fn(new Uint8Array(o))}}function fn(e){return Array.from(e,t=>t.toString(16).padStart(2,"0")).join("")}function $e(e){const t=bn(e.url),n=je(e),o=n?`chatgpt:${n}`:void 0,a=e.messages.filter(f=>f.text.trim().length>0).sort((f,u)=>f.ordinalHint-u.ordinalHint),i=a.filter(f=>f.role!=="unknown").length,r=a.length===0?0:a.reduce((f,u)=>f+u.semanticScore,0)/a.length,l=e.visibleErrors.map(f=>{const u=Ye(f);return{text:f,kind:u.kind,confidence:u.confidence}}).filter(f=>f.text.trim().length>0),S=[];t||S.push("unsupported_url"),o||S.push("missing_conversation_key"),a.length===0&&S.push("no_messages"),a.length>0&&i/a.length<.75&&S.push("weak_role_detection"),r<.6&&a.length>0&&S.push("weak_semantic_detection");const b=vn({supported:t,hasConversationKey:!!o,messageCount:a.length,knownRoleRatio:a.length===0?0:i/a.length,averageSemanticScore:r}),v={supported:t,messages:a,composerText:e.composerText??"",visibleErrors:l,generationState:e.generationState,health:b,coverageState:wn(e,b),tailEvidence:e.tailEvidence,reasons:S};return o&&(v.conversationKey=o),v}function je(e){if(Z(e.url))return;const t=re(e.url);if(t)return t;for(const n of e.conversationIdHints){const o=n.trim(),a=re(o);if(a)return a;if(/^[a-zA-Z0-9_-]{8,}$/.test(o))return o}}function Z(e){try{const t=new URL(e,"https://chatgpt.com");return t.hostname!=="chatgpt.com"?!1:t.pathname==="/"||t.pathname==="/chat"?!0:/^\/g\/[^/]+(?:\/project)?\/?$/.test(t.pathname)}catch{return!1}}function re(e){try{return new URL(e,"https://chatgpt.com").pathname.match(/(?:^|\/)c\/([^/?#]+)/)?.[1]}catch{return}}function bn(e){try{return new URL(e).hostname==="chatgpt.com"}catch{return!1}}function vn(e){return!e.supported||!e.hasConversationKey?"unreliable":e.messageCount===0?"degraded":e.knownRoleRatio>=.75&&e.averageSemanticScore>=.6?"healthy":e.knownRoleRatio>=.5?"degraded":"unreliable"}function wn(e,t){return t==="unreliable"?"unknown":e.messages.length>0&&(e.coverageEvidence==="observed_from_start"||e.coverageEvidence==="persisted_complete")?"complete":e.messages.length>0?"incomplete":"unknown"}function $t(e){if(!e.supported||!e.ledger)return"unavailable";const t=e.ledger;return t.parserHealth!=="healthy"||t.sequenceReliability==="uncertain"?"uncertain":t.coverageState==="complete"?"complete":t.coverageState==="mostly_complete"||t.coverageState==="incomplete"?"partial":"uncertain"}function Qe(e,t){return!e||!t?"unknown":e.parserSchemaVersion!==t.parserSchemaVersion||e.measurementSchemaVersion!==t.measurementSchemaVersion?"mismatch":"match"}function Sn(e,t){return Qe(e,t)==="match"}function xt(e,t){const n=Qe(e,t);return n==="match"?"verified":n==="mismatch"?"mismatch":"unverified"}function xe(e){if(e.calibrating)return"calibrating";const t=e.generation;if(!t)return"uncalibrated";const n=ke(t),o=t.warmStartPrior?.failureReference!==void 0||n.provisionalFailureReference!==void 0;if(!n.failureReference)return o?"stale":"uncalibrated";if(t.changePointSuggested)return"stale";const a=Qe(t.environmentSignature,e.currentEnvironment);return a==="mismatch"?"stale":a==="unknown"?"environment_unknown":n.failureReference.quality==="conservative"?"calibrated_conservative":"calibrated"}function Xe(e){return e==="calibrated"||e==="calibrated_conservative"}function yn(e){return!e.generation||xe({generation:e.generation,currentEnvironment:e.currentEnvironment})!=="stale"?!1:!!ke(e.generation).failureReference}function Je(e){return e==="complete"}function Cn(e){return e.coverageState==="complete"&&e.parserHealth==="healthy"&&e.sequenceReliability==="reliable"}function Ze(e){const t=e.ledger;return!!(t&&t.generationId===e.generationId&&Cn(t)&&Sn(t.environmentSignature,e.environmentSignature))}const Rt={unknown:0,normal:20,long:55,organize:72,high:90};function Tt(e){const t=Math.max(0,e.currentLoad),n=Math.max(0,e.composerDraftLoad),o=t+n,a=[];if(!Je(e.measurementState))return a.push(`measurement_${e.measurementState}`),Ie(o,a);if(!Xe(e.calibrationState))return a.push(`calibration_${e.calibrationState}`),Ie(o,a);const i=e.failureReference;if(!i||i.load<=0)return a.push("missing_empirical_failure_reference"),Ie(o,a);i.quality==="conservative"?a.push("conservative_failure_reference"):a.push("strong_failure_reference"),n>0&&a.push("composer_draft_included");const r=e.growthReserve!==void 0&&e.growthReserve>0?e.growthReserve:0,l=i.load,S=o+r;let b="normal";r>0?(a.push("turn_growth_reserve_ready"),o+r>=l?(b="high",a.push("projected_next_turn_reaches_reference")):o+2*r>=l?(b="organize",a.push("within_two_turn_growth_reserves")):o+3*r>=l&&(b="long",a.push("within_three_turn_growth_reserves"))):(a.push("turn_growth_reserve_learning"),o>=l&&(b="high",a.push("at_or_above_failure_reference")));const v=kn(o,l);return e.environmentConfidence==="mismatch"?(a.push("environment_mismatch"),Ie(S,a)):{state:b,score:Rt[b],referencePositionScore:v,projectedLoad:S,reasons:a}}function Ie(e,t,n=0){return{state:"unknown",score:Rt.unknown,referencePositionScore:n,projectedLoad:e,reasons:t}}function kn(e,t){return e<=0||t<=0?0:$n(e/t*100,0,100)}function $n(e,t,n){return Math.max(t,Math.min(n,e))}const At=2500;class De{constructor(t=At){this.stabilityMs=t}stabilityMs;candidate;completed=new Set;observe(t){if(!t.assistantFingerprint||t.role!=="assistant"||!t.contentFingerprint||t.tokenEstimate===void 0)return ge("no_active_assistant_tail",this.candidate);if(t.generationState==="generating")return this.reset({assistantFingerprint:t.assistantFingerprint,contentFingerprint:t.contentFingerprint,tokenEstimate:t.tokenEstimate,observedAt:t.observedAt}),ge("generation_in_progress",this.candidate);if(t.hasLengthError)return ge("length_error_visible",this.candidate);if(!this.candidate||this.candidate.assistantFingerprint!==t.assistantFingerprint||this.candidate.contentFingerprint!==t.contentFingerprint||this.candidate.tokenEstimate!==t.tokenEstimate)return this.reset({assistantFingerprint:t.assistantFingerprint,contentFingerprint:t.contentFingerprint,tokenEstimate:t.tokenEstimate,observedAt:t.observedAt}),ge("stability_window_open",this.candidate);if(t.observedAt-this.candidate.lastChangedAt<this.stabilityMs)return ge("stability_window_open",this.candidate);if(this.completed.has(t.assistantFingerprint))return ge("already_completed",this.candidate);const o={...this.candidate,completed:!0};return this.candidate=o,this.completed.add(t.assistantFingerprint),{state:"completed",candidate:o}}reset(t){this.candidate={assistantFingerprint:t.assistantFingerprint,contentFingerprint:t.contentFingerprint,tokenEstimate:t.tokenEstimate,firstObservedAt:t.observedAt,lastChangedAt:t.observedAt,completed:!1}}}function ge(e,t){const n={state:"pending",reason:e};return t&&(n.candidate=t),n}class xn{estimate(t){if(!t)return 0;let n=0,o=0,a=0;for(const i of t){const r=i.codePointAt(0)??0;r>=13312&&r<=19903||r>=19968&&r<=40959||r>=12352&&r<=12543||r>=44032&&r<=55215?n+=1:r<=127?o+=1:a+=1}return Math.max(1,Math.ceil(n*1.05+o/3.6+a/2))}}const Rn=1;function Mt(e){return e.privacyConsentVersion===Rn&&typeof e.privacyConsentedAt=="number"&&Number.isFinite(e.privacyConsentedAt)}function Tn(e){return!Mt(e)&&typeof e.privacyConsentDismissedAt=="number"&&Number.isFinite(e.privacyConsentDismissedAt)}const _t={unknown:-1,normal:0,long:1,organize:2,high:3};function An(e){const{state:t,control:n}=e;if(n?.muted||t!=="organize"&&t!=="high")return!1;const o=n?.lastAlertState;return!o||_t[t]>_t[o]}function Mn(e,t){return{...e??{},lastAlertState:t}}function _n(e){let t=!1,n=!1;const o=async()=>{if(t){n=!0;return}t=!0;try{do n=!1,await e();while(n)}finally{t=!1}};return()=>{o()}}function Ht(e,t){let n;return{schedule:()=>{n!==void 0&&clearTimeout(n),n=setTimeout(()=>{n=void 0,e()},t)},cancel:()=>{n!==void 0&&(clearTimeout(n),n=void 0)}}}const me=3e4;function Hn(){return{}}function Ue(e,t){return{blankSurfaceObserved:!0,pendingNewChatStartedAt:t}}function Et(){return{}}function En(e,t,n){return!e.activeConversationId&&!t?{state:e,resetPreviousBinding:!1}:{state:Ue(Et(),n),resetPreviousBinding:!0}}function Ln(e){return e.messageCount===0&&e.composerHasText&&!e.hasPersistedLedger}function Nn(e){return e.routeConversationId?e.routeConversationId:e.activeConversationId?e.activeConversationId:e.observedConversationId}function Fn(e,t){const n=Lt(e.pendingNewChatStartedAt,t.now),o=Lt(t.bridgedNewChatStartedAt,t.now),a=Pn(n,o);if(t.isBlankSurface){if(e.activeConversationId){const y=e.observedFromStartConversationId===e.activeConversationId;return{state:e,activeConversationId:e.activeConversationId,coverageEvidence:y?"observed_from_start":t.persistedAuthoritative?"persisted_complete":"none",consumedBridgedStart:!1}}return{state:{blankSurfaceObserved:!0,...a!==void 0?{pendingNewChatStartedAt:a}:{}},coverageEvidence:"none",consumedBridgedStart:!1}}const i=t.conversationId??e.activeConversationId;if(!i)return{state:a!==void 0?{pendingNewChatStartedAt:a}:{},coverageEvidence:"none",consumedBridgedStart:!1};const r=e.activeConversationId===i,l=e.observedFromStartConversationId===i,S=!r&&t.sameConversationEvidence===!0&&e.observedFromStartConversationId===e.activeConversationId,b=t.hasUserMessage&&(a!==void 0||e.blankSurfaceObserved===!0),v=l||S||b||t.verifiedInheritedPrefix===!0,f=!b&&a!==void 0&&t.messageCount===0,u={activeConversationId:i,...v?{observedFromStartConversationId:i}:{},...f?{pendingNewChatStartedAt:a}:{}},g=v?"observed_from_start":t.persistedAuthoritative?"persisted_complete":"none";return{state:u,activeConversationId:i,coverageEvidence:g,consumedBridgedStart:!!(o!==void 0&&b)&&(!r||!l)}}function Lt(e,t){if(e===void 0||!Number.isFinite(e))return;const n=t-e;return n>=0&&n<=me?e:void 0}function Pn(e,t){return e===void 0?t:t===void 0?e:Math.max(e,t)}function pe(e,t,n){const o=Z(t);return{url:t,title:e.title,documentText:"",conversationIdHints:o?[]:In(e,t),messages:o?[]:Nt(e),composerText:et(e),visibleErrors:o?[]:tt(e),generationState:Gn(e),coverageEvidence:n,tailEvidence:o?"unknown":Bn(e)}}function In(e,t){if(Z(t))return[];const n=[],o=re(t);o&&n.push(o);const a=e.querySelector('link[rel="canonical"]');if(a?.href){const i=re(a.href);i&&n.push(i)}for(const i of at(e)){let r=i;for(let l=0;r&&l<12;l+=1,r=r.parentElement){const S=r.getAttribute("data-conversation-id")?.trim();S&&n.push(S)}}return Array.from(new Set(n))}function Dn(e){return e.querySelector('[data-turn-key], [data-message-author-role], [data-turn="user"], [data-turn="assistant"], [data-testid*="conversation-turn"]')?!0:!!e.querySelector('main, [role="main"]')?.querySelector('article, [role="article"]')}function Nt(e){const t=Un(e),n=Array.from(e.querySelectorAll("[data-message-author-role]")),o=n.length>0?n:Array.from(e.querySelectorAll('[data-turn="user"], [data-turn="assistant"], article, [role="article"], [data-testid*="conversation-turn"]')),a=Oe(o),i=[];return a.forEach((r,l)=>{const S=ee(r);if(!S)return;const b=Wn(r),v=jn(r,b,n.length>0);if(v<.35)return;const f={role:b,text:S,ordinalHint:l,semanticScore:v,hasCode:r.querySelector("pre, code")!==null,attachmentCount:r.querySelectorAll('img, [data-testid*="attachment"]').length},u=Yn(r);u&&(f.stableHint=u),i.push(f)}),t.length===0?i:i.length===0?t:Ft(i)>Ft(t)?i:t}function Ft(e){const t=e.filter(i=>i.role==="user").length,n=e.filter(i=>i.role==="assistant").length,o=t+n;return Math.min(t,n)*1e3+o*10+e.length}function Un(e){const t=Array.from(e.querySelectorAll("[data-turn-key]"));if(t.length===0)return[];const n=[];for(const[o,a]of t.entries()){const i=a.getAttribute("data-turn-key")?.trim();if(!i)continue;const r=a.querySelector('[data-user-message-bubble], [data-message-author-role="user"], [data-turn="user"]'),l=r?ee(r):"";r&&l&&n.push(Pt("user",l,o*2,`turn-key:${i}:user`,[r]));const S=Array.from(a.querySelectorAll('[data-markdown-text-style="assistant-message"]')).filter(f=>ee(f));let b=S,v=S.map(ee).filter(Boolean).join(`

`);if(!v){const f=a.querySelector('[data-message-author-role="assistant"], [data-turn="assistant"]'),u=f?ee(f):"";f&&u&&(b=[f],v=u)}if(!v){const f=a.querySelector('[data-conversation-role="assistant"], [data-chatgpt-agent-turn-start]'),u=f?On(f,a):void 0,g=u?ee(u):"";u&&g&&(b=[u],v=g)}v&&n.push(Pt("assistant",v,o*2+1,`turn-key:${i}:assistant`,b))}return n}function On(e,t){let n=e;for(;n&&n!==t;){if(n.hasAttribute("data-content-search-unit-key"))return n;n=n.parentElement}}function Pt(e,t,n,o,a){return{role:e,text:t,stableHint:o,ordinalHint:n,semanticScore:1,hasCode:a.some(i=>i.querySelector("pre, code")!==null),attachmentCount:a.reduce((i,r)=>i+r.querySelectorAll('img, [data-testid*="attachment"]').length,0)}}function et(e){const t=It(e);return t?Qn(t):""}function It(e){const t=["#prompt-textarea",'[data-testid="prompt-textarea"]','[data-testid="chat-input"][contenteditable="true"]','[data-testid="chat-input"] [contenteditable="true"]','div.ProseMirror[contenteditable="true"]','div.ProseMirror[contenteditable="plaintext-only"]','[contenteditable="true"][role="textbox"]','[contenteditable="plaintext-only"][role="textbox"]','[aria-label*="Message ChatGPT" i]','[aria-label*="Ask ChatGPT" i]','[aria-label*="询问 ChatGPT" i]','[aria-label*="詢問 ChatGPT" i]','[placeholder*="询问 ChatGPT" i]','[placeholder*="詢問 ChatGPT" i]'],n=e.querySelector(t.join(", "));return n||Array.from(e.querySelectorAll('textarea, [contenteditable="true"], [contenteditable="plaintext-only"], [role="textbox"]')).find(a=>{if(a.matches('div.ProseMirror[contenteditable="true"], div.ProseMirror[contenteditable="plaintext-only"]')||a.closest?.('[data-testid="chat-input"], form'))return!0;const i=`${a.id} ${a.getAttribute("aria-label")??""} ${a.getAttribute("placeholder")??""}`;return/prompt|message chatgpt|ask chatgpt|send a message|询问 chatgpt|詢問 chatgpt|向 chatgpt 提问|向 chatgpt 提問|发送消息|傳送訊息/i.test(i)})}function tt(e){const t=Array.from(e.querySelectorAll('[role="alert"], [data-testid*="toast"]'));return Array.from(new Set(t.filter(n=>{if(n.hasAttribute("hidden")||n.getAttribute("aria-hidden")==="true"||typeof n.getClientRects=="function"&&n.getClientRects().length===0)return!1;const o='[data-turn-key], [data-message-author-role], [data-turn="user"], [data-turn="assistant"], [data-testid*="conversation-turn"], article, [role="article"]';let a=n;for(;a;){if(a.matches(o))return!1;a=a.parentElement}return!0}).map(ee).filter(n=>n.length>0&&n.length<=280)))}function Gn(e){return Array.from(e.querySelectorAll('button, [role="button"], [data-testid]')).some(n=>{const o=`${n.getAttribute("aria-label")??""} ${n.getAttribute("data-testid")??""} ${ee(n)}`;return/stop generating|stop response|停止生成|停止回答/i.test(o)})?"generating":"unknown"}function Bn(e){const n=at(e).at(-1);return n?Kn(n):"unknown"}function zn(e){const t=Array.from(e.querySelectorAll("[data-app-action-timeline-scroll], .thread-scroll-container"));for(const i of t)if(Dt(i)&&fe(i)>48&&nt(i))return i;const n=at(e),o=n[0],a=n.at(-1);if(o&&a){const r=Vn(o,a).find(nt);if(r)return r}for(const i of[e.scrollingElement,e.documentElement,e.body])if(Dt(i)&&fe(i)>48&&nt(i))return i}function Kn(e){const t=qn(e);if(!t)return"unknown";const n=t.scrollHeight-t.clientHeight-t.scrollTop;return Number.isFinite(n)?n<=24?"at_tail":"not_tail":"unknown"}function qn(e){let t=e.parentElement,n;for(;t;){if(fe(t)>48){if(ot(t))return t;n??=t}t=t.parentElement}return n}function Vn(e,t){const n=new Map;let o=0,a=t.parentElement;for(;a;){const i=fe(a);if(i>48){let r=Math.min(i,1e6);a.contains(e)&&a.contains(t)&&(r+=2e6),ot(a)&&(r+=1e6),(a.tagName.toLowerCase()==="main"||a.getAttribute("role")==="main")&&(r+=25e4),r+=Math.max(0,5e4-o*2e3),n.set(a,Math.max(n.get(a)??0,r))}a=a.parentElement,o+=1}for(o=0,a=e.parentElement;a;){const i=fe(a);if(i>48){let r=Math.min(i,1e6);a.contains(e)&&a.contains(t)&&(r+=2e6),ot(a)&&(r+=1e6),(a.tagName.toLowerCase()==="main"||a.getAttribute("role")==="main")&&(r+=25e4),r+=Math.max(0,5e4-o*2e3),n.set(a,Math.max(n.get(a)??0,r))}a=a.parentElement,o+=1}return Array.from(n.entries()).sort((i,r)=>r[1]-i[1]).map(([i])=>i)}function fe(e){return Math.max(0,e.scrollHeight-e.clientHeight)}function Dt(e){return!!(e&&typeof e.scrollTop=="number"&&typeof e.scrollHeight=="number"&&typeof e.clientHeight=="number")}function nt(e){const t=fe(e);if(t<=48)return!1;const n=e.scrollTop,o=[Math.min(t,n+16),n-16].filter((a,i,r)=>Math.abs(a-n)>=1&&r.indexOf(a)===i);try{for(const a of o)if(e.scrollTop=a,Math.abs(e.scrollTop-n)>=1)return e.scrollTop=n,!0;return e.scrollTop=n,!1}catch{try{e.scrollTop=n}catch{}return!1}}function at(e){const t=Array.from(e.querySelectorAll("[data-turn-key]"));if(t.length>0)return Oe(t);const n=Array.from(e.querySelectorAll("[data-message-author-role]"));return n.length>0?Oe(n):Oe(Array.from(e.querySelectorAll('[data-turn="user"], [data-turn="assistant"], article, [role="article"], [data-testid*="conversation-turn"]')))}function ot(e){const n=(typeof getComputedStyle=="function"?getComputedStyle(e):void 0)?.overflowY??e.style?.overflowY??"";return n?/(auto|scroll|overlay)/i.test(n):!0}function Oe(e){return e.filter(t=>!e.some(n=>n!==t&&n.contains(t)))}function Wn(e){const t=e.getAttribute("data-message-author-role")?.toLowerCase(),n=e.getAttribute("data-turn")?.toLowerCase(),o=e.getAttribute("aria-label")?.toLowerCase()??"",a=e.getAttribute("data-testid")?.toLowerCase()??"",i=`${t??""} ${n??""} ${o} ${a}`;return/\buser\b|you|human/.test(i)?"user":/assistant|chatgpt|gpt/.test(i)?"assistant":"unknown"}function Yn(e){const t=e.getAttribute("data-message-id")??e.getAttribute("data-message-id-anon")??void 0;if(t)return`data-message-id:${t}`;const n=e.getAttribute("data-testid")?.trim();if(n&&/conversation-turn-/i.test(n))return`conversation-turn:${n}`;for(const i of Array.from(e.attributes)){const r=i.name.toLowerCase();if(r.startsWith("data-")&&r.includes("message")&&r.includes("id")&&i.value.trim())return`${r}:${i.value.trim()}`}const o=e.id.trim();if(/message/i.test(o)&&!/conversation-turn/i.test(o))return`id:${o}`;let a=e.parentElement;for(let i=0;a&&i<5;i+=1,a=a.parentElement){const r=a.getAttribute("data-message-id")??a.getAttribute("data-message-id-anon");if(r?.trim())return`ancestor-message-id:${r.trim()}`;const l=a.getAttribute("data-testid")?.trim();if(l&&/conversation-turn-/i.test(l))return`conversation-turn:${l}`}}function jn(e,t,n){let o=0;return e.hasAttribute("data-message-author-role")&&(o+=.65),!n&&/^(user|assistant)$/i.test(e.getAttribute("data-turn")??"")&&(o+=.35),!n&&e.matches('article, [role="article"]')&&(o+=.35),!n&&e.getAttribute("data-testid")?.includes("conversation-turn")&&(o+=.25),t!=="unknown"&&(o+=.2),Math.min(1,o)}function Qn(e){const t=e.tagName.toLowerCase();return t==="textarea"||t==="input"?(e.value??"").trim():ee(e)}function ee(e){return(e.innerText||e.textContent||"").trim()}const Xn="chatgpt-dom-2026-10-v3",Jn=2;function Ut(e){if(e.length===0)return!1;const t=e.filter(o=>o.role==="user"||o.role==="assistant").length,n=e.reduce((o,a)=>o+a.semanticScore,0)/e.length;return t/e.length>=.9&&n>=.6}function ce(e){const t=Zn(e);return{parserSchemaVersion:Xn,measurementSchemaVersion:Jn,...t?{modelHint:t}:{}}}function Ot(e){const t=new Set;e.querySelector('[data-testid*="attachment" i], [data-testid*="file-pill" i], [aria-label*="attached" i]')&&t.add("attachment");const n=Array.from(e.querySelectorAll('[data-message-author-role="tool"], [data-testid*="tool-result" i], [data-testid*="tool-call" i], [data-testid*="web-result" i], [data-testid*="search-result" i], [data-testid*="code-output" i], [data-testid*="voice-message" i], [data-testid*="generated-image" i]')).map(o=>`${o.getAttribute("data-testid")??""} ${o.getAttribute("aria-label")??""}`).join(" ");return/web.?search|browse|search/i.test(n)&&t.add("web_search"),/code|python|analysis tool/i.test(n)&&t.add("code_execution"),/voice|audio/i.test(n)&&t.add("voice"),/image.?gen|generated.?image/i.test(n)&&t.add("generated_image"),/tool/i.test(n)&&t.add("tool_result"),[...t]}function Zn(e){const t=Array.from(e.querySelectorAll('[data-testid="model-switcher-dropdown-button"], [data-testid*="model-switcher" i]'));for(const n of t){const o=(n.innerText||n.textContent||"").trim();if(!(!o||o.length>80))return o.replace(/\s+/g," ")}}const Re=4,ea=240,ta=3,na=12;async function aa(e,t,n={}){const o=zn(e);return o?oa({surface:o,readWindow:()=>Nt(e),readUncertaintySources:()=>Ot(e),notifyScroll:()=>o.dispatchEvent(new Event("scroll",{bubbles:!0})),surfaceHint:sa(o,e),scrollMode:ia(o)},t,n):ca("no_scroll_container")}async function oa(e,t,n={}){const o=n.maxHeadRounds??32,a=n.maxSweepSteps??2e3,i=n.requiredStableRounds??3,r=n.requiredHeadStableRounds??4,l=n.maxEmptyWindowRetries??4,S=n.maxAlignmentRetries??6,b=n.stepRatio??.6,v=n.settle??la,f=n.headSettle??(n.settle?v:da),u=e.scrollMode??"normal",g=[],N=new Map;let y=[],z=0;const V=new Set,F=()=>Math.max(0,e.surface.scrollHeight-e.surface.clientHeight),O=()=>{const C=F();return u==="reversed"?Math.max(0,Math.min(C,e.surface.scrollTop+C)):Math.max(0,Math.min(C,e.surface.scrollTop))},oe=F()-O(),I=(C,h={})=>{const R={at:Date.now(),phase:C,scrollTop:e.surface.scrollTop,scrollHeight:e.surface.scrollHeight,clientHeight:e.surface.clientHeight,logicalTop:O(),scrollMode:u,...h};g.push(R),g.length>ea&&g.shift()},K=C=>{const h=F(),R=Math.max(0,Math.min(h,C));e.surface.scrollTop=u==="reversed"?R-h:R,e.notifyScroll?.()},le=()=>y.flatMap((C,h)=>{const R=N.get(C);return R?[{...R,ordinalHint:h}]:[]}),x=(C,h)=>{const R=le(),w=R.reduce((H,L)=>H+(L.role==="unknown"?1:0),0);return{complete:C,...h?{reason:h}:{},observedMessages:R,messageCount:R.length,attachmentCount:z,uncertaintySources:[...V],unknownRoleCount:w,diagnostics:[...g]}},D=(C,h)=>(I("failure",{...h!==void 0?{step:h}:{},reason:C,totalMessageCount:y.length}),x(!1,C)),te=async(C,h,R=v)=>{let w=e.readWindow(),H=0;for(;w.length===0&&H<l;)I(C,{...h!==void 0?{step:h}:{},pageMessageCount:0,totalMessageCount:y.length}),H+=1,await R(),w=e.readWindow();if(w.length===0)return{ok:!1,reason:"no_messages"};for(const E of e.readUncertaintySources?.()??[])V.add(E);const L=await t(w);return I(C,{...h!==void 0?{step:h}:{},pageMessageCount:w.length,observedCount:L.length,totalMessageCount:y.length}),L.length===0?{ok:!1,reason:"no_messages"}:(z=Math.max(z,L.reduce((E,Q)=>E+(Q.attachmentCount??0),0)),{ok:!0,observed:L,pageMessageCount:w.length})},T=C=>{const h=C.map(Gt);if(new Set(h).size!==h.length)return{ok:!1,reason:"window_alignment_failed"};if(C.forEach((H,L)=>{const E=h[L];E&&N.set(E,H)}),y.length===0)return y=[...h],{ok:!0,addedCount:h.length,firstVisible:h[0]??"",lastVisible:h.at(-1)??""};if(Bt(y,h)>=0)return{ok:!0,addedCount:0,firstVisible:h[0]??"",lastVisible:h.at(-1)??""};const R=ra(h,y);if(R<=0)return{ok:!1,reason:"window_alignment_failed"};const w=h.slice(0,h.length-R);return w.some(H=>y.includes(H))?{ok:!1,reason:"window_alignment_failed"}:(y=[...w,...y],{ok:!0,addedCount:w.length,firstVisible:h[0]??"",lastVisible:h.at(-1)??""})},j=async(C,h,R=v)=>{const w=await te(C,h,R);if(!w.ok)return w;const H=T(w.observed);return H.ok&&I("capture",{...h!==void 0?{step:h}:{},pageMessageCount:w.pageMessageCount,observedCount:w.observed.length,addedCount:H.addedCount,totalMessageCount:y.length}),H},Me=async C=>{let h=e.surface.scrollHeight,R=0;for(let w=0;w<na;w+=1){await v();const H=e.surface.scrollHeight;if(R=H===h?R+1:0,h=H,I("wait_load",{step:C,totalMessageCount:y.length}),R>=ta)break}return h},_e=async()=>{let C=0,h=-1;const R=Math.max(i*4,8);for(let w=0;w<R;w+=1){K(F()),await v();const H=e.surface.scrollHeight;if(C=F()-O()<=Re&&H===h?C+1:0,h=H,I("settle_bottom",{step:w,totalMessageCount:y.length}),C>=i)return!0}return!1},qe=async()=>{let C=0;for(let h=0;h<a;h+=1){const R=e.surface.scrollHeight,w=O(),H=Math.max(200,Math.floor(e.surface.clientHeight*b)),L=Math.max(0,w-H);K(L),I("scroll_up",{step:h,totalMessageCount:y.length}),await Me(h);let E=await j("capture",h,O()<=Re?f:v);if(!E.ok&&E.reason==="window_alignment_failed"){const ve=Math.max(1,w-L);for(let X=1;X<=S;X+=1){const we=Math.max(24,Math.floor(ve/2**X)),Se=Math.max(L,w-we);if(K(Se),I("scroll_up",{step:h,totalMessageCount:y.length}),await Me(h),E=await j("capture",h,O()<=Re?f:v),E.ok||E.reason!=="window_alignment_failed")break}}if(!E.ok)return{ok:!1,reason:E.reason,step:h};const Q=O()<=Re,Ve=E.addedCount===0&&e.surface.scrollHeight===R;if(Q&&Ve?C+=1:C=0,Q&&C>=i)return{ok:!0}}return{ok:!1,reason:"scan_limit_reached"}},ut=async(C,h)=>{const R=Math.max(48,Math.floor(e.surface.clientHeight/2)),w=Math.max(0,Math.min(F(),C)),H=[w,w-R,w+R,w-e.surface.clientHeight,w+e.surface.clientHeight,O()].map(L=>Math.max(0,Math.min(F(),Math.round(L)))).filter((L,E,Q)=>Q.indexOf(L)===E);for(const L of H){K(L),I("scroll_up",{step:h,totalMessageCount:y.length}),await Me(h);const E=await j("top_probe",h,v);if(E.ok)return{ok:!0};if(E.reason!=="window_alignment_failed")return E}return{ok:!1,reason:"window_alignment_failed"}};I("start",e.surfaceHint?{surfaceHint:e.surfaceHint}:{});try{if(!await _e())return D("tail_not_stable");const C=await j("capture");if(!C.ok)return D(C.reason);const h=C.lastVisible;if(!h)return D("no_messages");const R=await qe();if(!R.ok)return D(R.reason,R.step);let w="",H=-1,L=0;for(let X=0;X<o;X+=1){const we=e.surface.scrollHeight;K(10),await v(),K(0),await f();const Se=e.surface.scrollHeight,c=Math.max(0,Se-we);if(c>0){const A=await ut(c,X);if(!A.ok)return D(A.reason,X);const M=await qe();if(!M.ok)return D(M.reason,M.step);w="",H=e.surface.scrollHeight,L=0;continue}K(0),await v();const d=await j("top_probe",X,f);if(!d.ok)return D(d.reason,X);const m=d.firstVisible===w,$=e.surface.scrollHeight===H;if(L=O()<=Re&&m&&$&&d.addedCount===0?L+1:0,w=d.firstVisible,H=e.surface.scrollHeight,L>=r)break}if(L<r||!w)return D("head_not_stable");if(!await _e())return D("tail_not_stable");const E=await te("verify_tail");if(!E.ok)return D(E.reason);const Q=E.observed.map(Gt),ve=Bt(y,Q)>=0&&Q.at(-1)===h&&Q.at(-1)===y.at(-1);return I("verify_tail",{observedCount:E.observed.length,totalMessageCount:y.length}),ve?(I("complete",{totalMessageCount:y.length}),x(!0)):D("tail_not_stable")}finally{K(Math.max(0,F()-oe)),I("restore",{totalMessageCount:y.length})}}function ia(e){const t=e.scrollTop;try{e.scrollTop=-1;const n=e.scrollTop<0;return e.scrollTop=t,n?"reversed":"normal"}catch{try{e.scrollTop=t}catch{}return"normal"}}function sa(e,t){if(e===t.scrollingElement)return`document.scrollingElement:${e.tagName.toLowerCase()}`;if(e===t.documentElement)return`document.documentElement:${e.tagName.toLowerCase()}`;if(e===t.body)return`document.body:${e.tagName.toLowerCase()}`;const n=e.tagName.toLowerCase(),o=e.getAttribute("role")?.trim(),a=e.id.trim(),i=Array.from(e.classList).slice(0,4).join(".");return[n,a?`#${a}`:"",i?`.${i}`:"",o?`[role=${o}]`:""].join("")}function Gt(e){return e.stableHintHash?`stable:${e.stableHintHash}`:`${e.role}:${e.contentFingerprint}`}function Bt(e,t){if(t.length===0)return-1;for(let n=0;n<=e.length-t.length;n+=1)if(t.every((o,a)=>e[n+a]===o))return n;return-1}function ra(e,t){const n=Math.min(e.length,t.length);for(let o=n;o>0;o-=1)if(e.slice(e.length-o).every((a,i)=>a===t[i]))return o;return 0}function ca(e){return{complete:!1,reason:e,observedMessages:[],messageCount:0,attachmentCount:0,uncertaintySources:[],unknownRoleCount:0,diagnostics:[{at:Date.now(),phase:"failure",scrollTop:0,scrollHeight:0,clientHeight:0,reason:e}]}}async function la(){await new Promise(e=>window.setTimeout(e,300)),await new Promise(e=>requestAnimationFrame(()=>e()))}async function da(){await new Promise(e=>window.setTimeout(e,1200)),await new Promise(e=>requestAnimationFrame(()=>e()))}const zt=88,ua=135,ha=2400,ga=12,ma=2200;function it(e){return{scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}}function Kt(e,t,n){const o=Math.max(0,e.scrollHeight-e.clientHeight);return o<48?!1:t==="up"?n?e.scrollTop<=-o+4:e.scrollTop<=4:n?e.scrollTop>=-4:e.scrollTop>=o-4}function pa(e,t){return new Promise((n,o)=>{if(t.aborted){o(new Error("auto_scroll_cancelled"));return}const a=setTimeout(()=>{t.removeEventListener("abort",i),n()},e),i=()=>{clearTimeout(a),t.removeEventListener("abort",i),o(new Error("auto_scroll_cancelled"))};t.addEventListener("abort",i,{once:!0})})}async function qt(e,t,n,o,a,i={}){const r=i.maxSteps??ha,l=i.stableRounds??ga,S=i.settleMs??ma;let b=t.scrollTop<-4,v=!1,f=0;for(let u=0;u<r;u+=1){a();const g=it(t);await n(e==="up"?-zt:zt),await o(ua),a();const N=it(t);N.scrollTop<-4&&(b=!0);const y=Math.abs(N.scrollHeight-g.scrollHeight)>1,z=Math.abs(N.scrollTop-g.scrollTop)>1;if(z&&(v=!0),f=Kt(N,e,b)&&!y&&!z?f+1:0,u>0&&u%12===0&&await o(350),y&&await o(550),f<l)continue;await o(S),a();const F=it(t);if(!v||Math.abs(F.scrollHeight-N.scrollHeight)>1||!Kt(F,e,b)){if(f=0,!v&&u>l*2)throw new Error("auto_scroll_no_progress");continue}return}throw new Error("auto_scroll_limit_reached")}function fa(e){const t=["[data-app-action-timeline-scroll]",".thread-scroll-container",'[role="region"][aria-label]',"[data-scroll-root]","main",'[role="main"]'],n=Array.from(e.querySelectorAll(t.join(","))),o=e.scrollingElement;return o instanceof HTMLElement&&n.push(o),Array.from(new Set(n)).filter(r=>{const l=r.getBoundingClientRect();return(r===e.scrollingElement||/^(auto|scroll)$/.test(getComputedStyle(r).overflowY))&&r.scrollHeight>r.clientHeight+48&&l.width>150&&l.height>150&&l.bottom>0&&l.top<innerHeight}).sort((r,l)=>{const S=r.querySelector("[data-turn-key], [data-message-author-role]")?1:0,b=l.querySelector("[data-turn-key], [data-message-author-role]")?1:0,v=r.matches("[data-app-action-timeline-scroll], .thread-scroll-container")?1:0;return((l.matches("[data-app-action-timeline-scroll], .thread-scroll-container")?1:0)-v)*1e3+(b-S)*100+(l.clientHeight-r.clientHeight)/10})[0]}function ba(e){const t=e.getBoundingClientRect(),n=Math.round(Math.max(2,Math.min(innerWidth-2,t.left+t.width*.46))),o=Math.round(Math.max(2,Math.min(innerHeight-2,t.top+t.height*.56))),a=document.elementFromPoint(n,o);if(!a||e!==document.scrollingElement&&e!==document.documentElement&&!e.contains(a))throw new Error("auto_scroll_target_obstructed");return{x:n,y:o}}async function st(e){let t;const n=new Promise((o,a)=>{t=setTimeout(()=>a(new Error("auto_scroll_bridge_timeout")),8e3)});try{const o=await Promise.race([chrome.runtime.sendMessage(e),n]);if(!o?.ok)throw new Error(o?.error??"auto_scroll_bridge_unavailable")}finally{t&&clearTimeout(t)}}async function va(e,t,n=document){const o=fa(n);if(!o)throw new Error("auto_scroll_no_timeline");const a=location.pathname,i=crypto.randomUUID();let r=!1;const l=()=>{if(e.aborted)throw new Error("auto_scroll_cancelled");if(n.visibilityState==="hidden"||!n.hasFocus())throw new Error("auto_scroll_focus_lost");if(location.pathname!==a||!o.isConnected)throw new Error("auto_scroll_navigation")},S=async N=>{l();const y=ba(o);await st({type:"lcg.debugScroll.wheel",nonce:i,...y,deltaY:N})},b=N=>pa(N,e),v=N=>{N.type==="visibilitychange"&&n.visibilityState!=="hidden"||(f=!0)};let f=!1;const u=()=>{if(l(),f)throw new Error("auto_scroll_user_interrupted")},g=()=>{f=!0};n.addEventListener("pointerdown",v,!0),n.addEventListener("keydown",v,!0),n.addEventListener("visibilitychange",v),window.addEventListener("blur",g),window.addEventListener("pagehide",g);try{u(),await st({type:"lcg.debugScroll.start",nonce:i}),r=!0,t("up"),await qt("up",o,S,b,u),t("settle"),await b(800),u(),t("down"),await qt("down",o,S,b,u),t("done")}finally{n.removeEventListener("pointerdown",v,!0),n.removeEventListener("keydown",v,!0),n.removeEventListener("visibilitychange",v),window.removeEventListener("blur",g),window.removeEventListener("pagehide",g),r&&await st({type:"lcg.debugScroll.stop",nonce:i})}}async function wa(e,t,n,o){const a=()=>{if(e.aborted)throw new Error("auto_scroll_cancelled")};a(),await t(),a(),o(),a();const i=await n();return a(),i}const Sa={en:{extensionName:{message:"LongChat Guard"},extensionDescription:{message:"Local ChatGPT long-conversation risk warnings and handoff help; no official quota, no chat upload."},actionTitle:{message:"LongChat Guard"},autoShieldMode:{message:"Full conversation read"},autoShieldActivity:{message:"Working locally"},autoShieldQuietNote:{message:"Keep this tab active. You can stop the read at any time."},autoShieldCancel:{message:"Cancel"},autoShieldUp:{message:"Loading conversation history"},autoShieldUpHelp:{message:"Older messages are being loaded automatically. You can leave the scrolling to LongChat Guard."},autoShieldStepOne:{message:"01 / 03  ·  Load history"},autoShieldSettle:{message:"Waiting for history to settle"},autoShieldSettleHelp:{message:"Older parts of the conversation can load in batches. The reader is checking that they have settled."},autoShieldDown:{message:"Returning to the latest message"},autoShieldDownHelp:{message:"The page is moving back to the latest messages before the final reading check."},autoShieldStepTwo:{message:"02 / 03  ·  Return to latest"},autoShieldVerify:{message:"Checking message continuity"},autoShieldVerifyHelp:{message:"The full reader is verifying the sequence and both ends of the chat. Incomplete results will not be saved."},autoShieldStepThree:{message:"03 / 03  ·  Verify reading"},autoShieldSave:{message:"Finishing your read"},autoShieldSaveHelp:{message:"The reading passed the completeness checks. Your local results are being updated."},autoShieldStopping:{message:"Stopping safely"},autoShieldStoppingHelp:{message:"Your request is being cancelled. No incomplete result will be saved."},autoShieldStoppingStep:{message:"Cancellation requested"},autoShieldFinishing:{message:"Finishing…"},autoShieldCancelledNotice:{message:"Reading stopped. No incomplete result was saved."},autoReadRetryHelp:{message:"Automatic reading could not finish. Keep this ChatGPT tab in front and retry. Nothing incomplete was saved."},riskNormal:{message:"Lower risk"},riskLong:{message:"Long"},riskOrganize:{message:"Near risk"},riskHigh:{message:"High risk"},labelStatus:{message:"Status"},labelRisk:{message:"Risk"},labelLowRisk:{message:"Low risk"},labelHighRisk:{message:"High risk"},riskAdviceNormal:{message:"This chat is in the lower-risk range."},riskAdviceLong:{message:"This chat is getting long. Consider organizing important context."},riskAdviceOrganize:{message:"This chat is nearing the risk range. Prepare to continue in a new chat."},riskAdviceHigh:{message:"This chat is in the high-risk range. Continue in a new chat soon."},riskAdviceHighConservative:{message:"This chat is in the high-risk range. The reference is conservative, so continue in a new chat soon."},statusUncalibrated:{message:"Not calibrated"},statusCalibrating:{message:"Calibrating"},statusUnknown:{message:"Unable to assess"},statusEnvironmentUnknown:{message:"Unable to assess"},statusStale:{message:"Recalibration needed"},statusUncalibratedHelp:{message:"To enable risk alerts, calibrate with a historical chat that reached the conversation-length limit."},statusCalibratingHelp:{message:"Reading the full chat. Keep this page open."},statusMeasurementUncertainHelp:{message:"This chat has not been read reliably yet. Use “More” to run a full read."},statusEnvironmentUnknownHelp:{message:"Measurement is temporarily unavailable. Risk assessment will resume automatically."},statusStaleHelp:{message:"The measurement method has changed. Recalibrate to resume risk alerts."},statusConservativeCalibration:{message:"Reference established. This chat includes content that cannot be measured precisely, so alerts will be more conservative."},statusGrowthLearning:{message:"Reference established. Learning chat growth; until enough samples are available, alerts trigger only at the historical reference."},actionCopyContinuation:{message:"Copy continuation prompt"},actionCalibrateThisChat:{message:"Calibrate with this chat"},actionCalibrateThisChatHelp:{message:"Only use a historical chat you know reached the conversation-length limit."},actionCalibrating:{message:"Calibrating…"},actionMeasureCurrentChat:{message:"Read full current chat"},actionMeasuringCurrentChat:{message:"Reading full chat…"},measurementNoConversation:{message:"Open a chat first."},measurementScanIncomplete:{message:"Full read incomplete. Risk status was not updated. Keep the page open and try again."},measurementParserFailed:{message:"Some messages could not be read reliably. Risk status was not updated."},measurementScanSuccess:{message:"Full read complete. Risk status updated."},measurementConversationChanged:{message:"The chat changed during the read. Nothing was saved. Try again."},measurementGenerationChanged:{message:"The alert reference changed during the read. Try again."},measurementSampleUnusable:{message:"This chat cannot be read reliably right now. Risk status was not updated."},measurementScanFailed:{message:"Full read failed. Risk status was not updated."},menuMore:{message:"More"},actionDismiss:{message:"Dismiss"},actionRecalibrate:{message:"Recalibrate alert reference"},actionMute:{message:"Mute this chat"},actionRestore:{message:"Restore alerts"},passiveLimitQuestion:{message:"Possible conversation-length limit detected"},passiveLimitHelp:{message:"Use this chat as a calibration sample only if you know this was the conversation-length limit."},passiveLimitYes:{message:"Use this chat to calibrate"},passiveLimitNo:{message:"Ignore"},consentTitle:{message:"Enable local long-chat alerts"},consentLocalRead:{message:"Reads visible ChatGPT content locally to estimate long-chat risk."},consentAutoWheel:{message:"Full reads temporarily use browser debugging to scroll the current ChatGPT tab. Debugging ends when the read stops."},consentNoUpload:{message:"Does not upload chat content."},consentNoRawPersist:{message:"Does not save raw chat text."},consentDeleteLocal:{message:"Uninstall or clear extension data to remove local data."},consentAccept:{message:"Agree and start"},consentDecline:{message:"Not now"},pillAria:{message:"Open LongChat Guard"},pillConsentRequired:{message:"Consent required"},pillDisabled:{message:"Disabled"},continuationPrompt:{message:`Generate a continuation context for the current conversation that can be copied directly into a new chat.

Your task is not to summarize the chat history, and not to generate another prompt that the user must execute again. Instead, directly use all conversation context you currently know, together with any project context you can actually see that is relevant to the current task, to independently judge, select, deduplicate, correct, and organize the information into the final material another GPT can use to take over the work.

Assume the GPT taking over cannot see any other message from the current conversation and will see only this output.

Your goal is to let it recover the real current state of the work as accurately as possible from this material alone and continue from the correct point, without requiring the user to re-explain the background, repeating work that is already finished, retrying approaches that have already been ruled out, or mistaking historical state for current state.

## Core principles

Prioritize transferring the current valid working state, rather than retelling what this conversation once discussed.

Judge information by whether it will affect later understanding, judgment, decisions, or execution, not by how often or how extensively it appeared in the original conversation.

When historical content conflicts with later conclusions, prefer the latest valid state that is better supported by evidence and has been confirmed.

Do not keep obsolete information merely for completeness, and do not remove information genuinely needed to continue the work merely for brevity.

## Information you should independently decide to preserve

Select what is necessary for the actual conversation, including but not limited to:

- the real current goal, task, and problem to solve;
- project background and context necessary to understand the current work;
- requirements, boundaries, principles, preferences, quality standards, and non-negotiable constraints explicitly confirmed by the user;
- important work already completed and its actual current state;
- important conclusions, decisions, and approaches that have been confirmed;
- reasons, evidence, or key background necessary to understand those conclusions;
- directions already shown to be wrong, ineffective, abandoned, or not worth retrying;
- unresolved problems, blockers, risks, and items still requiring verification;
- the exact point the work has reached;
- what should be continued next;
- when later work depends on concrete technical state, the necessary files, directories, code locations, versions, branches, architecture, interfaces, data structures, configuration, test results, runtime environment, tool state, or other implementation details;
- important details that are easy to lose when switching chats but would affect later judgment;
- working methods, decision rules, and behavioral requirements the user has explicitly required future work to continue following.

The above is not a fixed template that must be output item by item. Decide the structure and information density according to the actual task.

## State accuracy

Clearly distinguish:

- confirmed facts;
- confirmed decisions;
- hypotheses or judgments that are still currently valid;
- items that still require verification.

Do not present a hypothesis, possibility, or former suspicion as a confirmed fact.

If an early judgment was later disproved by evidence, use the latest conclusion. Preserve an explanation of why that wrong direction should not be revisited only when it still matters for future work.

If the same item went through multiple revisions during the conversation, keep only the currently valid version, adding the key reason for the current state only when necessary.

If you cannot confirm something, do not fill gaps, guess, or fabricate. Preserve its uncertainty, or omit it when it has no value for continuation.

## Compression rules

Actively remove:

- greetings and social content;
- repeated statements;
- intermediate versions superseded by later state;
- discussion process that does not affect future work;
- temporary issues already resolved that will not affect future work;
- side details unrelated to the current goal;
- information included only to retell the chronological order of the chat.

However, do not remove the following merely to make the output shorter, even if they take more space:

- constraints that would change future decisions;
- approaches the user has explicitly rejected;
- important failed attempts and their confirmed causes;
- the real current implementation or working state;
- important risks that are still unverified;
- information whose absence would likely cause the new chat to repeat a mistake.

## Self-contained requirement

The final material must be understandable independently of the original conversation.

Do not use vague references that only make sense in the original conversation, such as:

“the thing above”
“the issue just now”
“the previous code”
“the second option”
“that thing you mentioned earlier”

If such information matters for continuation, rewrite it explicitly.

Do not assume the new GPT knows anything that happened in the current conversation.

## Optimize for takeover, not review

If the current work is software development, debugging, research, design, writing, planning, or another ongoing task, prioritize preserving:

the current state, valid conclusions, constraints, unfinished work, and next actions.

Do not write a chronological meeting-minutes-style review of the conversation.

After reading the result, the new GPT should be able to clearly answer:

- what is being worked on now;
- what the final goal is;
- why the current direction is being used;
- what has already been completed;
- what the real current state is;
- what has already been confirmed;
- which conclusions should not be reopened without new evidence;
- which failed directions should not be retried;
- what remains uncertain;
- what work is still unfinished;
- where to continue next.

If there is a clear next step, put it at the end of the final material and make it specific enough that the new GPT can immediately continue executing it.

## Output requirements

Output the final continuation context directly.

Do not generate a second-level prompt.
Do not ask me to give another prompt back to you for execution.
Do not answer the current business task itself.
Do not explain how you performed the organization.
Do not evaluate the quality of the result.
Do not add usage instructions.
Do not ask the user to provide information you already know from the current context.
Do not mechanically force the result into fixed sections merely for formatting.
Do not include content with no practical value for continuation.

Let the task complexity determine the output length: simple conversations should be concise, complex projects may be detailed, but every retained detail should serve accurate takeover in the new chat.

Now directly generate the final continuation context.`},toastContinuationCopied:{message:"Continuation prompt copied"},toastCopyFailed:{message:"Copy failed. Please try again."},toastActionFailed:{message:"Action failed. Please try again."},toastRecalibrationStarted:{message:"Recalibration started. Use a historical limit-hit chat to establish a new reference."},toastRemindersRestored:{message:"Alerts restored for this chat"},toastConversationMuted:{message:"Alerts turned off for this chat"},toastFailureLearned:{message:"This limit event was recorded."},toastFailureIgnored:{message:"This event was ignored."},toastMonitoringEnabled:{message:"Local long-chat alerts enabled"},toastMonitoringDeferred:{message:"Not enabled"},calibrationNoConversation:{message:"Open a historical chat you know reached the conversation-length limit."},calibrationParserFailed:{message:"Some messages could not be read reliably. Calibration was not saved."},calibrationConservativeSuccess:{message:"Calibration complete. This chat includes content that cannot be measured precisely, so alerts will be more conservative."},calibrationSuccess:{message:"Calibration complete. Alert reference established."},calibrationConversationChanged:{message:"The chat changed during calibration. Nothing was saved. Try again."},calibrationGenerationChanged:{message:"The alert reference changed during calibration. Try again."},calibrationSampleUnusable:{message:"This chat cannot be read reliably and was not saved as a calibration sample."},toastScanFailed:{message:"Calibration did not finish. The alert reference was not updated."},scanNoScroll:{message:"Conversation area not found. Refresh and try again."},scanNoMessages:{message:"No chat content is available yet. Wait for the page to load and try again."},scanHeadLoading:{message:"Older history is still loading. Keep the page open and try again."},scanTailChanging:{message:"The chat is still updating. Wait for it to finish and try again."},scanAlignmentFailed:{message:"Part of the history could not be read continuously. Calibration stopped."},scanLimitReached:{message:"Full history could not be confirmed. Calibration was not saved."},scanIncomplete:{message:"Full history could not be confirmed. Calibration was not saved."}},zh_CN:{extensionName:{message:"LongChat Guard · 长会话预警"},extensionDescription:{message:"ChatGPT 长会话风险提醒与续接辅助；本地处理，不显示官方额度，不上传聊天正文。"},actionTitle:{message:"LongChat Guard"},autoShieldMode:{message:"会话完整读取"},autoShieldActivity:{message:"正在本地处理"},autoShieldQuietNote:{message:"请保持当前标签页在前台，读取期间可随时取消。"},autoShieldCancel:{message:"取消读取"},autoShieldUp:{message:"正在加载历史消息"},autoShieldUpHelp:{message:"正在自动向上加载较早的聊天内容，无需手动滚动或操作页面。"},autoShieldStepOne:{message:"01 / 03  ·  加载历史"},autoShieldSettle:{message:"等待历史内容加载稳定"},autoShieldSettleHelp:{message:"历史消息可能分批显示，正在确认较早内容已稳定呈现。"},autoShieldDown:{message:"正在返回最新消息"},autoShieldDownHelp:{message:"正在自动返回会话底部，为接下来的完整读取校验做准备。"},autoShieldStepTwo:{message:"02 / 03  ·  返回最新"},autoShieldVerify:{message:"正在检查会话完整性"},autoShieldVerifyHelp:{message:"正在检查消息顺序与两端是否连续。无法确认完整的结果不会保存。"},autoShieldStepThree:{message:"03 / 03  ·  校验结果"},autoShieldSave:{message:"正在完成读取"},autoShieldSaveHelp:{message:"已通过完整性检查，正在更新本地读取结果。"},autoShieldStopping:{message:"正在安全停止"},autoShieldStoppingHelp:{message:"已收到取消请求，不会保存本次未完成的读取结果。"},autoShieldStoppingStep:{message:"已请求取消"},autoShieldFinishing:{message:"正在完成…"},autoShieldCancelledNotice:{message:"读取已停止，未保存不完整的结果。"},autoReadRetryHelp:{message:"自动读取未能完成，请保持当前 ChatGPT 标签页在前台后重试。本次不完整数据未保存。"},riskNormal:{message:"风险较低"},riskLong:{message:"偏长"},riskOrganize:{message:"接近风险"},riskHigh:{message:"高风险"},labelStatus:{message:"状态"},labelRisk:{message:"风险"},labelLowRisk:{message:"低风险"},labelHighRisk:{message:"高风险"},riskAdviceNormal:{message:"当前会话处于较低风险区。"},riskAdviceLong:{message:"会话已偏长，建议整理重要内容。"},riskAdviceOrganize:{message:"已接近风险区，建议准备续接新会话。"},riskAdviceHigh:{message:"已进入高风险区，建议尽快续接新会话。"},riskAdviceHighConservative:{message:"已进入高风险区。由于参考更保守，建议尽快续接新会话。"},statusUncalibrated:{message:"未校准"},statusCalibrating:{message:"正在校准"},statusUnknown:{message:"暂无法判断"},statusEnvironmentUnknown:{message:"暂无法判断"},statusStale:{message:"需要重新校准"},statusUncalibratedHelp:{message:"要启用风险提醒，请用一个已达到长度上限的历史会话完成校准。"},statusCalibratingHelp:{message:"正在完整读取会话，请保持此页面打开。"},statusMeasurementUncertainHelp:{message:"当前会话尚未完成可靠读取。可从“···”中重新完整读取。"},statusEnvironmentUnknownHelp:{message:"当前测量暂不可用，恢复后会自动继续判断。"},statusStaleHelp:{message:"测量方式已更新，请重新校准后继续使用风险提醒。"},statusConservativeCalibration:{message:"基准已建立。该会话含无法精确计量的内容，提醒会更保守。"},statusGrowthLearning:{message:"基准已建立，正在学习会话增长。样本充足前，仅在达到历史参考时提醒。"},actionCopyContinuation:{message:"复制续接提示词"},actionCalibrateThisChat:{message:"用此会话校准"},actionCalibrateThisChatHelp:{message:"仅用于你确认已达到会话长度上限的历史会话。"},actionCalibrating:{message:"正在校准…"},actionMeasureCurrentChat:{message:"完整读取当前会话"},actionMeasuringCurrentChat:{message:"正在完整读取…"},measurementNoConversation:{message:"请先打开一个会话。"},measurementScanIncomplete:{message:"未能完整读取，风险状态未更新。请保持页面打开后重试。"},measurementParserFailed:{message:"部分消息无法可靠识别，风险状态未更新。"},measurementScanSuccess:{message:"完整读取完成，风险状态已更新。"},measurementConversationChanged:{message:"读取期间会话发生变化，结果未保存。请重试。"},measurementGenerationChanged:{message:"读取期间提醒基准发生变化，请重试。"},measurementSampleUnusable:{message:"当前会话暂无法可靠读取，风险状态未更新。"},measurementScanFailed:{message:"完整读取失败，风险状态未更新。"},menuMore:{message:"更多"},actionDismiss:{message:"关闭"},actionRecalibrate:{message:"重新校准提醒基准"},actionMute:{message:"本会话不提醒"},actionRestore:{message:"恢复提醒"},passiveLimitQuestion:{message:"检测到可能的会话长度上限"},passiveLimitHelp:{message:"只有当你确认这次确实是会话长度上限时，才用此会话作为校准样本。"},passiveLimitYes:{message:"用此会话校准"},passiveLimitNo:{message:"忽略"},consentTitle:{message:"启用本地长会话预警"},consentLocalRead:{message:"仅在本机读取当前 ChatGPT 页面内容用于长会话趋势判断。"},consentAutoWheel:{message:"主动完整读取时会临时使用浏览器调试权限滚动当前 ChatGPT 页面，读取停止后即断开调试连接。"},consentNoUpload:{message:"不上传聊天内容。"},consentNoRawPersist:{message:"不保存聊天正文。"},consentDeleteLocal:{message:"可通过卸载扩展或清除扩展数据删除本地数据。"},consentAccept:{message:"同意并开始"},consentDecline:{message:"暂不开启"},pillAria:{message:"打开 LongChat Guard"},pillConsentRequired:{message:"需要同意"},pillDisabled:{message:"未启用"},continuationPrompt:{message:`请为当前会话生成一份可直接复制到新会话使用的“续接上下文”。

你的任务不是总结聊天记录，也不是生成另一个需要再次执行的提示词，而是直接利用你当前已经掌握的全部会话上下文，以及你实际可见且与当前任务有关的项目上下文，自主完成判断、筛选、去重、校正和整理，输出最终可供另一个 GPT 接管工作的内容。

假设接手的新 GPT 看不到当前会话中的任何其他消息，只能看到你这一次输出。

你的目标是让它仅凭这份内容，就能尽可能准确地恢复当前工作的真实状态，从正确的位置继续，而不需要用户重新解释背景，不重复已经完成的工作，不重新尝试已经排除的方案，也不误把历史状态当成当前状态。

## 核心原则

优先迁移“当前有效的工作状态”，而不是复述“这个会话曾经聊过什么”。

信息的重要性由它是否会影响后续理解、判断、决策或执行决定，而不是由它在原会话中出现的次数或篇幅决定。

当历史内容与后来的结论发生冲突时，以最新、证据更充分、已经确认的有效状态为准。

不要为了完整而保留已经失效的信息，也不要为了简短而删除后续继续工作真正需要的信息。

## 你需要自主判断并保留的内容

根据当前会话实际情况选择必要内容，包括但不限于：

- 当前真正的目标、任务以及要解决的问题；
- 理解当前工作所必需的项目背景和上下文；
- 用户已经明确确认的需求、边界、原则、偏好、质量标准和不可违反的约束；
- 已经完成的重要工作以及当前真实状态；
- 已经确认的重要结论、决策和方案；
- 理解这些结论所必需的原因、证据或关键背景；
- 已经验证为错误、无效、废弃或不应再次尝试的方向；
- 当前仍未解决的问题、阻塞点、风险和待验证事项；
- 当前工作具体进行到了什么位置；
- 下一步应当直接继续什么；
- 如果后续工作依赖具体技术状态，应保留必要的文件、目录、代码位置、版本、分支、架构、接口、数据结构、配置、测试结果、运行环境、工具状态或其他实现信息；
- 容易因为切换会话而丢失、但会影响后续判断的重要细节；
- 用户明确要求后续继续遵守的工作方法、决策方式和行为要求。

以上不是必须逐项输出的固定模板。请根据当前任务自行决定结构和信息密度。

## 状态准确性

必须明确区分：

- 已确认的事实；
- 已确认的决策；
- 当前仍然成立的推测或判断；
- 尚待验证的事项。

不要把推测、可能性或曾经的怀疑写成已经确认的事实。

如果某个早期判断后来已经被证据否定，应以最新结论为准。只有当“这个错误方向为什么不能再走”对后续工作仍然重要时，才保留必要说明。

如果同一事项在会话中经历过多次修改，只保留当前有效版本，并在确有必要时补充导致当前状态的关键原因。

如果你不能确认某项信息，不要自行补全、猜测或编造；应保留其不确定性，或者在对续接没有价值时省略。

## 压缩规则

主动删除：

- 寒暄和社交性内容；
- 重复表达；
- 已被后续状态覆盖的中间版本；
- 不影响后续工作的讨论过程；
- 已解决且不会影响后续工作的临时问题；
- 与当前目标无关的枝节；
- 纯粹为了复述聊天顺序而存在的信息。

但以下内容即使篇幅较长，也不应仅为了压缩而删除：

- 会改变后续决策的限制条件；
- 用户已经明确否决的做法；
- 重要的失败经验及其确定原因；
- 当前实现或工作的真实状态；
- 尚未验证的关键风险；
- 新会话如果不知道就很可能重复犯错的信息。

## 自包含要求

最终内容必须能够脱离原会话独立理解。

不要使用只有原会话才能理解的模糊指代，例如：

“上面那个”
“刚才的问题”
“之前的代码”
“第二个方案”
“你前面说的那个”

如果这些内容对续接重要，请将它们改写成明确的信息。

不要假设新 GPT 知道当前会话发生过什么。

## 面向接管，而不是面向回顾

如果当前属于软件开发、调试、研究、设计、写作、规划或其他持续性工作，应优先保存：

当前状态、有效结论、约束条件、未完成事项和下一步行动。

不要写成按时间顺序回顾聊天过程的会议纪要。

新 GPT 阅读完后，应该能够明确回答：

- 现在正在做什么；
- 最终目标是什么；
- 当前为什么采用这个方向；
- 已经完成了什么；
- 当前真实状态是什么；
- 哪些事情已经确认；
- 哪些结论不要重新推翻；
- 哪些错误方向不要重新尝试；
- 哪些内容仍然不确定；
- 还剩什么没有完成；
- 下一步应该直接从哪里继续。

如果当前存在一个明确的下一步，请在最终内容末尾明确写出，并使其具体到接手者可以直接继续执行。

## 输出要求

直接输出最终续接上下文。

不要生成二级提示词。
不要让我再次把某个提示词交给你执行。
不要回答当前业务任务本身。
不要解释你如何进行了整理。
不要评价这份整理。
不要添加使用教程。
不要要求用户补充你在当前上下文中已经知道的信息。
不要为了形式整齐而机械套用固定栏目。
不要包含对续接无实际价值的内容。

输出长度由当前任务复杂程度决定：简单会话应简洁，复杂项目可以详细，但所有保留下来的内容都应服务于新会话的准确接管。

现在直接生成最终的续接上下文。`},toastContinuationCopied:{message:"续接提示词已复制"},toastCopyFailed:{message:"复制失败，请手动重试"},toastActionFailed:{message:"操作失败，请稍后重试"},toastRecalibrationStarted:{message:"已进入重新校准模式，请用达到长度上限的历史会话建立新基准。"},toastRemindersRestored:{message:"已恢复本会话提醒"},toastConversationMuted:{message:"已关闭本会话提醒"},toastFailureLearned:{message:"已记录本次长度上限事件"},toastFailureIgnored:{message:"已忽略这次事件"},toastMonitoringEnabled:{message:"已启用本地长会话预警"},toastMonitoringDeferred:{message:"暂不开启"},calibrationNoConversation:{message:"请先打开一个你确认已达到长度上限的历史会话。"},calibrationParserFailed:{message:"部分消息无法可靠识别，校准未保存。"},calibrationConservativeSuccess:{message:"校准完成。该会话含无法精确计量的内容，提醒会更保守。"},calibrationSuccess:{message:"校准完成，提醒基准已建立。"},calibrationConversationChanged:{message:"校准期间会话发生变化，结果未保存。请重试。"},calibrationGenerationChanged:{message:"校准期间提醒基准发生变化，请重试。"},calibrationSampleUnusable:{message:"当前会话无法可靠读取，未作为校准样本保存。"},toastScanFailed:{message:"校准未完成，提醒基准未更新。"},scanNoScroll:{message:"无法定位会话区域，请刷新后重试。"},scanNoMessages:{message:"尚未读取到会话内容，请等待页面加载后重试。"},scanHeadLoading:{message:"历史内容仍在加载，请保持页面打开后重试。"},scanTailChanging:{message:"会话仍在更新，请等待完成后重试。"},scanAlignmentFailed:{message:"部分历史内容未能连续读取，校准已停止。"},scanLimitReached:{message:"未能确认完整历史，校准未保存。"},scanIncomplete:{message:"未能确认完整历史，校准未保存。"}},zh_TW:{extensionName:{message:"LongChat Guard · 長對話預警"},extensionDescription:{message:"ChatGPT 長對話風險提醒與續接輔助；本機處理，不顯示官方額度，不上傳聊天原文。"},actionTitle:{message:"LongChat Guard"},autoShieldMode:{message:"對話完整讀取"},autoShieldActivity:{message:"正在本機處理"},autoShieldQuietNote:{message:"請保持目前分頁在前景，讀取期間可隨時取消。"},autoShieldCancel:{message:"取消讀取"},autoShieldUp:{message:"正在載入歷史訊息"},autoShieldUpHelp:{message:"正在自動向上載入較早的對話內容，無須手動捲動或操作頁面。"},autoShieldStepOne:{message:"01 / 03  ·  載入歷史"},autoShieldSettle:{message:"等待歷史內容載入穩定"},autoShieldSettleHelp:{message:"歷史訊息可能分批顯示，正在確認較早內容已穩定呈現。"},autoShieldDown:{message:"正在返回最新訊息"},autoShieldDownHelp:{message:"正在自動返回對話底部，為接下來的完整讀取驗證做準備。"},autoShieldStepTwo:{message:"02 / 03  ·  返回最新"},autoShieldVerify:{message:"正在檢查對話完整性"},autoShieldVerifyHelp:{message:"正在檢查訊息順序與兩端是否連續。無法確認完整的結果不會儲存。"},autoShieldStepThree:{message:"03 / 03  ·  驗證結果"},autoShieldSave:{message:"正在完成讀取"},autoShieldSaveHelp:{message:"已通過完整性檢查，正在更新本機讀取結果。"},autoShieldStopping:{message:"正在安全停止"},autoShieldStoppingHelp:{message:"已收到取消要求，不會儲存本次未完成的讀取結果。"},autoShieldStoppingStep:{message:"已要求取消"},autoShieldFinishing:{message:"正在完成…"},autoShieldCancelledNotice:{message:"讀取已停止，未儲存不完整的結果。"},autoReadRetryHelp:{message:"自動讀取未能完成，請保持目前 ChatGPT 分頁在前景後重試。本次不完整資料未儲存。"},riskNormal:{message:"風險較低"},riskLong:{message:"偏長"},riskOrganize:{message:"接近風險"},riskHigh:{message:"高風險"},labelStatus:{message:"狀態"},labelRisk:{message:"風險"},labelLowRisk:{message:"低風險"},labelHighRisk:{message:"高風險"},riskAdviceNormal:{message:"目前對話處於較低風險區。"},riskAdviceLong:{message:"對話已偏長，建議整理重要內容。"},riskAdviceOrganize:{message:"已接近風險區，建議準備續接新對話。"},riskAdviceHigh:{message:"已進入高風險區，建議盡快續接新對話。"},riskAdviceHighConservative:{message:"已進入高風險區。由於參考更保守，建議盡快續接新對話。"},statusUncalibrated:{message:"未校準"},statusCalibrating:{message:"正在校準"},statusUnknown:{message:"暫無法判斷"},statusEnvironmentUnknown:{message:"暫無法判斷"},statusStale:{message:"需要重新校準"},statusUncalibratedHelp:{message:"要啟用風險提醒，請用一個已達到長度上限的歷史對話完成校準。"},statusCalibratingHelp:{message:"正在完整讀取對話，請保持此頁面開啟。"},statusMeasurementUncertainHelp:{message:"目前對話尚未完成可靠讀取。可從「···」中重新完整讀取。"},statusEnvironmentUnknownHelp:{message:"目前測量暫不可用，恢復後會自動繼續判斷。"},statusStaleHelp:{message:"測量方式已更新，請重新校準後繼續使用風險提醒。"},statusConservativeCalibration:{message:"基準已建立。此對話含無法精確計量的內容，提醒會更保守。"},statusGrowthLearning:{message:"基準已建立，正在學習對話增長。樣本充足前，僅在達到歷史參考時提醒。"},actionCopyContinuation:{message:"複製續接提示詞"},actionCalibrateThisChat:{message:"用此對話校準"},actionCalibrateThisChatHelp:{message:"僅用於你確認已達到對話長度上限的歷史對話。"},actionCalibrating:{message:"正在校準…"},actionMeasureCurrentChat:{message:"完整讀取目前對話"},actionMeasuringCurrentChat:{message:"正在完整讀取…"},measurementNoConversation:{message:"請先開啟一個對話。"},measurementScanIncomplete:{message:"未能完整讀取，風險狀態未更新。請保持頁面開啟後重試。"},measurementParserFailed:{message:"部分訊息無法可靠識別，風險狀態未更新。"},measurementScanSuccess:{message:"完整讀取完成，風險狀態已更新。"},measurementConversationChanged:{message:"讀取期間對話發生變化，結果未儲存。請重試。"},measurementGenerationChanged:{message:"讀取期間提醒基準發生變化，請重試。"},measurementSampleUnusable:{message:"目前對話暫無法可靠讀取，風險狀態未更新。"},measurementScanFailed:{message:"完整讀取失敗，風險狀態未更新。"},menuMore:{message:"更多"},actionDismiss:{message:"關閉"},actionRecalibrate:{message:"重新校準提醒基準"},actionMute:{message:"本對話不提醒"},actionRestore:{message:"恢復提醒"},passiveLimitQuestion:{message:"偵測到可能的對話長度上限"},passiveLimitHelp:{message:"只有當你確認這次確實是對話長度上限時，才用此對話作為校準樣本。"},passiveLimitYes:{message:"用此對話校準"},passiveLimitNo:{message:"忽略"},consentTitle:{message:"啟用本機長對話預警"},consentLocalRead:{message:"僅在本機讀取目前 ChatGPT 頁面內容，用於長對話趨勢判斷。"},consentAutoWheel:{message:"主動完整讀取時會暫時使用瀏覽器偵錯權限捲動目前的 ChatGPT 頁面，讀取停止後即中斷偵錯連線。"},consentNoUpload:{message:"不上傳聊天內容。"},consentNoRawPersist:{message:"不儲存聊天原文。"},consentDeleteLocal:{message:"可透過解除安裝擴充功能或清除擴充功能資料刪除本機資料。"},consentAccept:{message:"同意並開始"},consentDecline:{message:"暫不啟用"},pillAria:{message:"開啟 LongChat Guard"},pillConsentRequired:{message:"需要同意"},pillDisabled:{message:"未啟用"},continuationPrompt:{message:`請為目前對話產生一份可直接複製到新對話使用的「續接上下文」。

你的任務不是總結聊天紀錄，也不是產生另一個需要再次執行的提示詞，而是直接利用你當前已經掌握的全部對話上下文，以及你實際可見且與當前任務有關的專案上下文，自主完成判斷、篩選、去重、校正和整理，輸出最終可供另一個 GPT 接管工作的內容。

假設接手的新 GPT 看不到目前對話中的任何其他訊息，只能看到你這一次輸出。

你的目標是讓它僅憑這份內容，就能盡可能準確地恢復當前工作的真實狀態，從正確的位置繼續，而不需要使用者重新解釋背景，不重復已經完成的工作，不重新嘗試已經排除的方案，也不誤把歷史狀態當成當前狀態。

## 核心原則

優先遷移「當前有效的工作狀態」，而不是重述「這個對話曾經聊過什麼」。

資訊的重要性由它是否會影響後續理解、判斷、決策或執行決定，而不是由它在原對話中出現的次數或篇幅決定。

當歷史內容與后來的結論發生衝突時，以最新、證據更充分、已經確認的有效狀態為準。

不要為了完整而保留已經失效的資訊，也不要為了簡短而刪除後續繼續工作真正需要的資訊。

## 你需要自主判斷並保留的內容

根據目前對話實際情況選擇必要內容，包括但不限於：

- 當前真正的目標、任務以及要解決的問題；
- 理解當前工作所必需的專案背景和上下文；
- 使用者已經明確確認的需求、邊界、原則、偏好、品質標準和不可違反的約束；
- 已經完成的重要工作以及當前真實狀態；
- 已經確認的重要結論、決策和方案；
- 理解這些結論所必需的原因、證據或關鍵背景；
- 已經驗證為錯誤、無效、廢棄或不應再次嘗試的方向；
- 當前仍未解決的問題、阻塞點、風險和待驗證事項；
- 當前工作具體進行到了什麼位置；
- 下一步應當直接繼續什麼；
- 如果後續工作依賴具體技術狀態，應保留必要的文件、目錄、程式碼位置、版本、分支、架構、接口、資料結構、設定、測試結果、執行環境、工具狀態或其他實現資訊；
- 容易因為切換對話而丟失、但會影響後續判斷的重要細節；
- 使用者明確要求後續繼續遵守的工作方法、決策方式和行為要求。

以上不是必須逐項輸出的固定模板。請根據當前任務自行決定結構和資訊密度。

## 狀態準確性

必須明確區分：

- 已確認的事實；
- 已確認的決策；
- 當前仍然成立的推測或判斷；
- 尚待驗證的事項。

不要把推測、可能性或曾經的懷疑寫成已經確認的事實。

如果某個早期判斷后來已經被證據否定，應以最新結論為準。只有當「這個錯誤方向為什麼不能再走」對後續工作仍然重要時，才保留必要說明。

如果同一事項在對話中經歷過多次修改，只保留當前有效版本，並在確有必要時補充導致當前狀態的關鍵原因。

如果你不能確認某項資訊，不要自行補全、猜測或編造；應保留其不確定性，或者在對續接沒有價值時省略。

## 壓縮規則

主動刪除：

- 寒暄和社交性內容；
- 重復表達；
- 已被後續狀態覆蓋的中間版本；
- 不影響後續工作的討論過程；
- 已解決且不會影響後續工作的臨時問題；
- 與當前目標無關的枝節；
- 純粹為了重述聊天順序而存在的資訊。

但以下內容即使篇幅較長，也不應僅為了壓縮而刪除：

- 會改變後續決策的限制條件；
- 使用者已經明確否決的做法；
- 重要的失敗經驗及其確定原因；
- 當前實現或工作的真實狀態；
- 尚未驗證的關鍵風險；
- 新對話如果不知道就很可能重復犯錯的資訊。

## 自包含要求

最終內容必須能夠脫離原對話獨立理解。

不要使用只有原對話才能理解的模糊指代，例如：

「上面那個」
「剛才的問題」
「之前的程式碼」
「第二個方案」
「你前面說的那個」

如果這些內容對續接重要，請將它們改寫成明確的資訊。

不要假設新 GPT 知道目前對話發生過什麼。

## 面向接管，而不是面向回顧

如果當前屬於軟體開發、除錯、研究、設計、寫作、規劃或其他持續性工作，應優先保存：

當前狀態、有效結論、約束條件、未完成事項和下一步行動。

不要寫成按時間順序回顧聊天過程的會議紀要。

新 GPT 閱讀完后，應該能夠明確回答：

- 現在正在做什麼；
- 最終目標是什麼；
- 當前為什麼采用這個方向；
- 已經完成了什麼；
- 當前真實狀態是什麼；
- 哪些事情已經確認；
- 哪些結論不要重新推翻；
- 哪些錯誤方向不要重新嘗試；
- 哪些內容仍然不確定；
- 還剩什麼沒有完成；
- 下一步應該直接從哪里繼續。

如果當前存在一個明確的下一步，請在最終內容末尾明確寫出，並使其具體到接手者可以直接繼續執行。

## 輸出要求

直接輸出最終續接上下文。

不要產生二級提示詞。
不要讓我再次把某個提示詞交給你執行。
不要回答當前業務任務本身。
不要解釋你如何進行了整理。
不要評價這份整理。
不要添加使用教程。
不要要求使用者補充你在當前上下文中已經知道的資訊。
不要為了形式整齊而機械套用固定欄目。
不要包含對續接無實際價值的內容。

輸出長度由當前任務復雜程度決定：簡單對話應簡潔，復雜專案可以詳細，但所有保留下來的內容都應服務於新對話的準確接管。

現在直接產生最終的續接上下文。`},toastContinuationCopied:{message:"續接提示詞已複製"},toastCopyFailed:{message:"複製失敗，請再試一次"},toastActionFailed:{message:"操作失敗，請稍後再試"},toastRecalibrationStarted:{message:"已進入重新校準模式，請用達到長度上限的歷史對話建立新基準。"},toastRemindersRestored:{message:"已恢復本對話提醒"},toastConversationMuted:{message:"已關閉本對話提醒"},toastFailureLearned:{message:"已記錄本次長度上限事件"},toastFailureIgnored:{message:"已忽略這次事件"},toastMonitoringEnabled:{message:"已啟用本機長對話預警"},toastMonitoringDeferred:{message:"暫不啟用"},calibrationNoConversation:{message:"請先開啟一個你確認已達到長度上限的歷史對話。"},calibrationParserFailed:{message:"部分訊息無法可靠識別，校準未儲存。"},calibrationConservativeSuccess:{message:"校準完成。此對話含無法精確計量的內容，提醒會更保守。"},calibrationSuccess:{message:"校準完成，提醒基準已建立。"},calibrationConversationChanged:{message:"校準期間對話發生變化，結果未儲存。請重試。"},calibrationGenerationChanged:{message:"校準期間提醒基準發生變化，請重試。"},calibrationSampleUnusable:{message:"目前對話無法可靠讀取，未作為校準樣本儲存。"},toastScanFailed:{message:"校準未完成，提醒基準未更新。"},scanNoScroll:{message:"無法定位對話區域，請重新整理後重試。"},scanNoMessages:{message:"尚未讀取到對話內容，請等待頁面載入後重試。"},scanHeadLoading:{message:"歷史內容仍在載入，請保持頁面開啟後重試。"},scanTailChanging:{message:"對話仍在更新，請等待完成後重試。"},scanAlignmentFailed:{message:"部分歷史內容未能連續讀取，校準已停止。"},scanLimitReached:{message:"未能確認完整歷史，校準未儲存。"},scanIncomplete:{message:"未能確認完整歷史，校準未儲存。"}}},rt=new Map;function s(e,t){const n=rt.get(e);if(n)return n;try{if(typeof chrome<"u"&&chrome.i18n?.getMessage){const i=chrome.i18n.getMessage(e);if(i)return rt.set(e,i),i}}catch{}const o=ya([Ca(),ka(),$a()]),a=Sa[o][e]?.message;return a?(rt.set(e,a),a):t}function ya(e){for(const t of e){const n=t?.trim().replace("_","-").toLowerCase();if(n){if(n==="zh-tw"||n==="zh-hk"||n==="zh-mo"||n.startsWith("zh-hant"))return"zh_TW";if(n==="zh"||n==="zh-cn"||n==="zh-sg"||n.startsWith("zh-hans"))return"zh_CN";if(n.startsWith("en"))return"en"}}return"en"}function Ca(){try{if(typeof chrome<"u"&&chrome.i18n?.getUILanguage)return chrome.i18n.getUILanguage()}catch{}}function ka(){try{return typeof document<"u"?document.documentElement?.lang:void 0}catch{return}}function $a(){try{return typeof navigator<"u"?navigator.language:void 0}catch{return}}function xa(e,t,n){return e==="wheel"?"allow":e==="keydown"&&t==="Escape"?"cancel":n&&["keydown","keyup","keypress"].includes(e)&&(t==="Enter"||t===" "||t==="Spacebar")||n&&(e.startsWith("pointer")||e.startsWith("mouse")||e.startsWith("touch")||e==="click"||e==="auxclick"||e==="dblclick")?"allow":"block"}const Vt=["pointerdown","pointerup","mousedown","mouseup","click","auxclick","dblclick","contextmenu","touchstart","touchend","touchmove","keydown","keyup","keypress","beforeinput","input","submit","dragstart","drop","selectstart"];function Ra(e,t=document,n=window){const o=t.createElement("div");o.dataset.longChatAutoReadShield="true",o.style.cssText="position:fixed;inset:0;z-index:2147483647;pointer-events:none;isolation:isolate;";const a=o.attachShadow({mode:"open"});a.innerHTML=`
    <style>
      :host {
        all: initial;
        pointer-events: none;
        --accent: #188b7c;
        --accent-soft: #e2f3ee;
        --ink: #142a35;
        --muted: #62727d;
      }
      * { box-sizing: border-box; }
      .veil {
        position: fixed; inset: 0; pointer-events: none;
        background: rgba(12, 24, 35, .28);
      }
      .banner {
        position: fixed; top: clamp(16px, 8vh, 88px); left: 50%;
        transform: translateX(-50%); width: min(472px, calc(100vw - 28px));
        padding: 24px 26px 20px;
        color: var(--ink); background: rgba(255, 255, 255, .97);
        border: 1px solid rgba(225, 235, 235, .96);
        border-radius: 22px;
        box-shadow: 0 32px 90px rgba(9, 29, 40, .23),
                    0 3px 12px rgba(9, 29, 40, .055);
        pointer-events: none; overflow: hidden;
        font: 400 13px/1.55 system-ui, -apple-system, "Segoe UI",
          "PingFang SC", "Microsoft YaHei", sans-serif;
        -webkit-font-smoothing: antialiased;
      }
      .banner::before {
        content: ""; position: absolute; top: 0; left: 25px; right: 25px;
        height: 2px; border-radius: 0 0 4px 4px;
        background: linear-gradient(90deg, #62c6ae, #1b8d7c 62%, #c9ece4);
      }
      .topline { display:flex; align-items:center; gap:11px; }
      .mark {
        width: 38px; height: 38px; flex: 0 0 38px;
        border-radius: 12px; display:grid; place-items:center;
        background: linear-gradient(145deg, #173a43, #286c64);
        box-shadow: 0 4px 12px rgba(22, 100, 90, .16);
      }
      .mark svg { width:23px; height:23px; display:block; }
      .identity { display:flex; flex-direction:column; gap:1px; min-width:0; }
      .heading { font-size:14px; font-weight:710; letter-spacing:-.2px; }
      .mode { font-size:11px; color:#81919a; line-height:1.3; }
      .activity {
        margin-left:auto; display:flex; align-items:center; gap:6px;
        padding:5px 9px; border-radius:99px; white-space:nowrap;
        background:var(--accent-soft); color:#157b70;
        font-size:10px; font-weight:650;
      }
      .activity-dot {
        width:6px; height:6px; border-radius:50%;
        background:var(--accent);
        box-shadow:0 0 0 3px rgba(24,139,124,.11);
        animation: breathe 1.8s ease-in-out infinite;
      }
      .content { margin-top:23px; }
      .eyebrow { margin:0 0 4px; color:var(--accent);
        font-size:11px; font-weight:660; letter-spacing:.35px; }
      .state { margin:0; font-size:21px; line-height:1.38;
        font-weight:720; letter-spacing:-.6px; color:var(--ink); }
      .explanation { margin:9px 0 0; min-height:39px; max-width:405px;
        font-size:12px; color:var(--muted); line-height:1.7; }
      .progress { margin-top:22px; display:grid; grid-template-columns:repeat(3,1fr);
        gap:7px; }
      .bar { height:5px; border-radius:999px; background:#e3e9eb;
        overflow:hidden; position:relative; }
      .bar::after { content:""; position:absolute; inset:0;
        border-radius:inherit; background:linear-gradient(90deg,#1b9381,#61c9ac);
        opacity:0; transform:scaleX(.22); transform-origin:left;
        transition:transform .35s ease, opacity .3s ease; }
      :host([data-stage="up"]) .bar.one::after,
      :host([data-stage="settle"]) .bar.one::after,
      :host([data-stage="down"]) .bar.one::after,
      :host([data-stage="verify"]) .bar.one::after,
      :host([data-stage="save"]) .bar.one::after,
      :host([data-stage="down"]) .bar.two::after,
      :host([data-stage="verify"]) .bar.two::after,
      :host([data-stage="save"]) .bar.two::after,
      :host([data-stage="verify"]) .bar.three::after,
      :host([data-stage="save"]) .bar.three::after {
        opacity:1; transform:scaleX(1); }
      :host([data-stage="up"]) .bar.one::after,
      :host([data-stage="settle"]) .bar.one::after,
      :host([data-stage="down"]) .bar.two::after,
      :host([data-stage="verify"]) .bar.three::after {
        animation: grow 1.7s ease-in-out infinite alternate; }
      .steps { margin:8px 0 0; font-size:11px; color:#73838a;
        font-weight:550; }
      .bottom { display:flex; align-items:center; justify-content:space-between;
        gap:14px; margin-top:20px; padding-top:16px;
        border-top:1px solid #edf1f1; }
      .footnote { font-size:11px; line-height:1.55;
        color:#7f8f96; max-width:240px; }
      .cancel {
        pointer-events:auto; flex:0 0 auto; min-width:93px; min-height:36px;
        padding:8px 13px; border:1px solid #d9e2e3;
        background:#f8faf9; color:#3b555c;
        border-radius:10px; font-size:12px; font-weight:650; line-height:1.3;
        font-family:inherit;
        cursor:pointer; transition:background .16s, border-color .16s, transform .16s;
      }
      .cancel:hover:not(:disabled) { background:#edf5f2; border-color:#b9d9d2; }
      .cancel:active:not(:disabled) { transform:scale(.98); }
      .cancel:focus-visible { outline:3px solid #37a88c; outline-offset:3px; }
      .cancel:disabled { opacity:.54; cursor:default; }
      @keyframes grow { from { opacity:.7; } to { opacity:1; } }
      @keyframes breathe { 50% { box-shadow:0 0 0 5px rgba(24,139,124,.07); } }
      @media (max-width:420px) {
        .banner { padding:19px 18px 16px; border-radius:18px; }
        .state { font-size:19px; }
        .content { margin-top:19px; }
        .footnote { max-width:190px; }
      }
      @media (prefers-reduced-motion:reduce) {
        .activity-dot,.bar::after { animation:none !important; }
        .bar::after,.cancel { transition:none !important; }
      }
      @media (prefers-color-scheme: dark) {
        :host { --ink:#eff6f4; --muted:#a9b9bc; --accent:#6dd6b9; --accent-soft:#203f3d; }
        .veil { background:rgba(3,9,15,.44); }
        .banner { color:var(--ink); background:rgba(26,34,42,.97);
          border-color:#354a4d; box-shadow:0 30px 90px rgba(0,0,0,.38); }
        .mode,.steps,.footnote { color:#93a6ab; }
        .activity { color:#8ce1c7; }
        .bar { background:#3a4a50; }
        .bottom { border-top-color:#35464b; }
        .cancel { background:#2b3b40; color:#e1eeeb; border-color:#486066; }
        .cancel:hover:not(:disabled) { background:#36534f; border-color:#6ca89b; }
      }
    </style>
    <div class="veil" aria-hidden="true"></div>
    <section class="banner" role="status" aria-live="polite" aria-atomic="true">
      <div class="topline">
        <span class="mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="white"
               stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
            <path d="M5 7h14M5 12h10M5 17h7"/>
            <path d="m16 16 2 2 3-4"/>
          </svg>
        </span>
        <span class="identity">
          <strong class="heading" data-role="heading"></strong>
          <span class="mode" data-role="mode"></span>
        </span>
        <span class="activity"><span class="activity-dot" aria-hidden="true"></span><span data-role="activity"></span></span>
      </div>
      <div class="content">
        <p class="eyebrow" data-role="steps"></p>
        <p class="state" data-role="state"></p>
        <p class="explanation" data-role="explanation"></p>
        <div class="progress" aria-hidden="true">
          <span class="bar one"></span>
          <span class="bar two"></span>
          <span class="bar three"></span>
        </div>
      </div>
      <div class="bottom">
        <span class="footnote" data-role="footnote"></span>
        <button class="cancel" data-role="cancel" type="button"></button>
      </div>
    </section>
  `;const i=x=>{const D=a.querySelector(x);if(!D)throw new Error("auto_shield_missing_element");return D},r=i('[data-role="heading"]'),l=i('[data-role="mode"]'),S=i('[data-role="activity"]'),b=i('[data-role="footnote"]'),v=i('[data-role="state"]'),f=i('[data-role="explanation"]'),u=i('[data-role="steps"]'),g=i('[data-role="cancel"]');r.textContent="LongChat Guard",l.textContent=s("autoShieldMode","Full conversation read"),S.textContent=s("autoShieldActivity","Reading locally"),b.textContent=s("autoShieldQuietNote","Keep this tab active. You can stop at any time."),g.textContent=s("autoShieldCancel","Cancel");let N="up",y=!1,z=!1;const V=x=>{y||z||N==="save"||N==="stopping"||(z=!0,K("stopping"),e(x))},F=x=>{if(y)return;const D=x.composedPath().includes(g),te=xa(x.type,"key"in x&&typeof x.key=="string"?x.key:void 0,D);te!=="allow"&&(x.cancelable&&x.preventDefault(),x.stopImmediatePropagation(),te==="cancel"&&V("user_cancelled"))},O=x=>{x.target===n&&V("auto_scroll_focus_lost")},oe=()=>{V("auto_scroll_focus_lost")},I=()=>{t.visibilityState==="hidden"&&oe()},K=x=>{if(y||z&&x!=="stopping")return;N=x,o.dataset.stage=x;const D={up:[s("autoShieldUp","Loading older messages"),s("autoShieldUpHelp","Browser wheel input is moving slowly upward. Keep this tab active and do not use your mouse or keyboard."),s("autoShieldStepOne","Step 1: Load history")],settle:[s("autoShieldSettle","Waiting for history to stabilize"),s("autoShieldSettleHelp","Older messages may load in several batches; reaching the top once does not prove completion."),s("autoShieldStepOne","Step 1: Load history")],down:[s("autoShieldDown","Returning to the latest message"),s("autoShieldDownHelp","The browser is scrolling back down while the page renders its message windows."),s("autoShieldStepTwo","Step 2: Return to the latest message")],verify:[s("autoShieldVerify","Checking conversation continuity"),s("autoShieldVerifyHelp","The original full reader is checking both ends and the message sequence. Results are not saved unless verification succeeds."),s("autoShieldStepThree","Step 3: Verify complete reading")],save:[s("autoShieldSave","Saving verified measurement"),s("autoShieldSaveHelp","The scan passed its checks. Finishing the local update."),s("autoShieldStepThree","Step 3: Verify complete reading")],stopping:[s("autoShieldStopping","Stopping automatic reading"),s("autoShieldStoppingHelp","Finishing safely. An unfinished read will not be saved."),s("autoShieldStoppingStep","Cancellation requested")]},[te,T,j]=D[x];v.textContent=te,f.textContent=T,u.textContent=j,g.disabled=x==="save"||x==="stopping",g.textContent=x==="save"?s("autoShieldFinishing","Finishing…"):x==="stopping"?s("autoShieldStoppingStep","Stopping…"):s("autoShieldCancel","Cancel")},le=()=>{V("user_cancelled")};g.addEventListener("click",le);for(const x of Vt)n.addEventListener(x,F,{capture:!0,passive:!1});n.addEventListener("blur",O),n.addEventListener("pagehide",oe),t.addEventListener("visibilitychange",I,!0),t.documentElement.appendChild(o),K("up");try{g.focus({preventScroll:!0})}catch{}return{setStage:K,getStage:()=>N,close(){if(!y){y=!0,g.removeEventListener("click",le);for(const x of Vt)n.removeEventListener(x,F,!0);n.removeEventListener("blur",O),n.removeEventListener("pagehide",oe),t.removeEventListener("visibilitychange",I,!0),o.remove()}}}}const Ta=15*6e4;function Wt(e){const{turn:t}=e;if(e.errorKind!=="conversation_length_limit"||e.confidence!=="high"||!t?.accepted&&!t?.submitted||t.lengthErrorVisibleAtStart===!0||t.conversationKey!==e.conversationKey||t.generationId!==e.generationId)return!1;const n=e.observedAt-t.capturedAt;return Number.isFinite(n)&&n>=0&&n<=Ta}function Yt(e){const t=e?.closest('button,[role="button"],[role="menuitem"],a[href]');if(!t)return!1;const n=[t.getAttribute("data-testid")??"",t.getAttribute("aria-label")??"",t.getAttribute("title")??"",t.textContent??""].join(" ").trim();return/branch[\s_-]*(?:in|to)?[\s_-]*(?:a[\s_-]*)?new[\s_-]*chat|branch[\s_-]*(?:conversation|chat)|(?:建立|创建|建立新的|創建|建立新|建立一個)(?:会话|聊天|對話)?分支|(?:在新聊天中|在新對話中)(?:建立|创建|創建)分支|另開分支/i.test(n)}function Aa(e){const t=new Map(e.messages.map(n=>[n.fingerprint,n]));return e.activeFingerprints.map(n=>t.get(n))}function Ma(e){const t=e.observed;if(!(t.length<2||t[0]?.role!=="user"||!t.some(n=>n.role==="assistant")||t.some(n=>n.role==="unknown"||!n.contentFingerprint||!Number.isFinite(n.tokenEstimate))))for(const[n,o]of Object.entries(e.ledgers)){if(n===e.currentConversationKey||!Ze({ledger:o,generationId:e.generationId,environmentSignature:e.environmentSignature})||o.uncertaintySources.length!==0)continue;const a=Aa(o);if(!(t.length>a.length||a.some((i,r)=>r<t.length&&!i))&&t.every((i,r)=>i.role===a[r]?.role&&i.contentFingerprint===a[r]?.contentFingerprint&&i.tokenEstimate===a[r]?.tokenEstimate))return n}}class _a{constructor(t=850){this.minimumStableMs=t}minimumStableMs;pending;observe(t){const{newConversationId:n,sourceKey:o,messageFingerprints:a,observedAt:i}=t;if(!n||!o||a.length<2)return this.pending=void 0,!1;const r=JSON.stringify([n,o,a]);return this.pending?.key!==r||i<this.pending.lastAt?(this.pending={key:r,since:i,lastAt:i,visits:1},!1):(this.pending.lastAt=i,this.pending.visits+=1,this.pending.visits>=2&&i-this.pending.since>=this.minimumStableMs)}reset(){this.pending=void 0}}const Ha="conversation-guard-root",Ge="__conversationGuardUiDestroy",be=["Reads visible ChatGPT content locally to estimate long-chat risk.","Does not upload chat content.","Does not save raw chat text.","Uninstall or clear extension data to remove local data.","Agree and start","Not now"];class Ea{constructor(t){this.callbacks=t;const n=globalThis;n[Ge]?.(),this.root=document.createElement("div"),this.root.id=Ha,this.root.style.cssText="position:fixed;right:16px;bottom:16px;z-index:2147483647;pointer-events:auto;",this.shadow=this.root.attachShadow({mode:"open"}),this.shadow.innerHTML=Pa(),document.documentElement.appendChild(this.root),this.pill=U(this.shadow,'[data-role="pill"]'),this.panel=U(this.shadow,'[data-role="panel"]'),this.monitorPanel=U(this.shadow,'[data-role="monitor-panel"]'),this.consentPanel=U(this.shadow,'[data-role="consent-panel"]'),this.statusDot=U(this.shadow,'[data-role="status-dot"]'),this.statusText=U(this.shadow,'[data-role="status-text"]'),this.toast=U(this.shadow,'[data-role="toast"]'),this.menuTrigger=U(this.shadow,'[data-role="menu-trigger"]'),this.menuPopover=U(this.shadow,'[data-role="menu-popover"]'),this.scanNotice=U(this.shadow,'[data-role="scan-notice"]'),this.scanNoticeText=U(this.shadow,'[data-role="scan-notice-text"]'),this.pill.addEventListener("click",()=>{if(this.mode==="disabled"){this.showConsentCard();return}this.setOpen(!this.open)}),this.bindButton("copy",t.onCopyContinuation),this.bindButton("calibrate",t.onCalibrate),this.bindMenuAction("measure-current",t.onMeasureCurrentChat),this.bindMenuAction("relearn",t.onRecalibrate),this.bindMenuAction("mute",t.onToggleMute),this.bindButton("confirm-yes",()=>t.onConfirmFailure(!0)),this.bindButton("confirm-no",()=>t.onConfirmFailure(!1)),this.bindButton("consent-accept",t.onAcceptPrivacyConsent),this.bindButton("consent-decline",t.onDeclinePrivacyConsent),this.bindButton("scan-notice-dismiss",()=>this.clearScanNotice()),this.menuTrigger.addEventListener("click",()=>{this.setMenuOpen(!this.menuOpen,!1,!0)}),this.menuPopover.addEventListener("keydown",o=>{this.handleMenuKeyDown(o)}),document.addEventListener("pointerdown",this.onDocumentPointerDown,!0),document.addEventListener("keydown",this.onDocumentKeyDown,!0),window.addEventListener("resize",this.onWindowResize),n[Ge]=this.destroyGlobalHook}callbacks;root;shadow;pill;panel;monitorPanel;consentPanel;statusDot;statusText;toast;menuTrigger;menuPopover;scanNotice;scanNoticeText;mode="monitoring";open=!1;menuOpen=!1;calibrationBusy=!1;measurementBusy=!1;preBusyCalibrationState;toastTimer;latestModel;lastRenderSignature;onDocumentPointerDown=t=>{if(!this.open)return;const n=t.composedPath();this.menuOpen&&!n.includes(this.menuTrigger)&&!n.includes(this.menuPopover)&&this.setMenuOpen(!1),Ba(n,this.root)&&this.setOpen(!1)};onDocumentKeyDown=t=>{if(!(!this.open||!za(t.key))){if(this.menuOpen){t.preventDefault(),this.setMenuOpen(!1,!0);return}this.setOpen(!1)}};onWindowResize=()=>{this.menuOpen&&this.positionMenuPopover()};destroyGlobalHook=()=>this.destroy();update(t){this.latestModel=t;const n=JSON.stringify({model:t,calibrationBusy:this.calibrationBusy,measurementBusy:this.measurementBusy});if(this.mode==="monitoring"&&n===this.lastRenderSignature)return;this.lastRenderSignature=n,this.mode="monitoring",this.monitorPanel.hidden=!1,this.consentPanel.hidden=!0;const o=La(t);this.root.dataset.risk=t.riskState,this.statusText.textContent=o.label,this.statusDot.dataset.risk=t.riskState;const a=Oa(t);Te(this.shadow,"card-caption",a?s("labelRisk","Risk"):s("labelStatus","Status")),Te(this.shadow,"card-status",o.label);const i=U(this.shadow,'[data-role="trend"]');i.dataset.risk=t.riskState,i.dataset.trackAvailable=String(a);const r=U(this.shadow,'[data-role="risk-track"]'),l=U(this.shadow,'[data-role="risk-scale"]');r.hidden=!a,l.hidden=!a;const S=a?Ua(t.referencePositionScore):0;r.querySelectorAll("[data-risk-segment]").forEach((F,O)=>{F.dataset.active=String(O<S)});const b=U(this.shadow,'[data-role="risk-advice"]'),v=Na(t);b.hidden=!v,b.textContent=v;const f=ae(this.shadow,"calibrate"),u=ae(this.shadow,"measure-current"),g=ae(this.shadow,"relearn");u.disabled=this.measurementBusy||this.calibrationBusy,g.disabled=this.measurementBusy||this.calibrationBusy,Te(this.shadow,"measure-current-label",this.measurementBusy?s("actionMeasuringCurrentChat","Reading full chat…"):s("actionMeasureCurrentChat","Read full current chat"));const N=!!t.conversationKey&&(t.calibrationState==="uncalibrated"||t.calibrationState==="stale"||t.calibrationState==="calibrating");f.hidden=!N,f.disabled=this.calibrationBusy||this.measurementBusy||t.calibrationState==="calibrating",Te(this.shadow,"calibrate-label",this.calibrationBusy||t.calibrationState==="calibrating"?s("actionCalibrating","Calibrating…"):s("actionCalibrateThisChat","Calibrate with this chat"));const y=U(this.shadow,'[data-role="pending-confirm"]');y.hidden=!t.pendingFailureConfirmation;const z=ae(this.shadow,"copy");z.hidden=t.riskState!=="organize"&&t.riskState!=="high";const V=ae(this.shadow,"mute");Te(this.shadow,"mute-label",t.muted?s("actionRestore","Restore alerts"):s("actionMute","Mute this chat")),V.disabled=!t.conversationKey}setCalibrationBusy(t){if(t&&!this.calibrationBusy&&(this.preBusyCalibrationState=this.latestModel?.calibrationState),this.calibrationBusy=t,t&&this.clearScanNotice(),this.latestModel){const n={...this.latestModel,calibrationState:t?"calibrating":this.preBusyCalibrationState??this.latestModel.calibrationState};this.update(n)}t||(this.preBusyCalibrationState=void 0)}setMeasurementBusy(t){this.measurementBusy=t,t&&this.clearScanNotice(),this.latestModel&&this.update(this.latestModel)}setOpen(t){this.open=t,this.panel.hidden=!t,this.pill.setAttribute("aria-expanded",String(t)),t||this.setMenuOpen(!1)}drawAttention(){this.setOpen(!0),this.root.classList.remove("guard-attention"),this.root.offsetWidth,this.root.classList.add("guard-attention")}showToast(t,n=2600){this.toastTimer!==void 0&&window.clearTimeout(this.toastTimer),this.toast.textContent=t,this.toast.hidden=!1,this.toastTimer=window.setTimeout(()=>{this.toast.hidden=!0,this.toastTimer=void 0},n)}showScanNotice(t,n="warning"){this.scanNoticeText.textContent=t,this.scanNotice.dataset.tone=n,this.scanNotice.hidden=!1,this.setOpen(!0)}clearScanNotice(){this.scanNotice.hidden=!0,this.scanNoticeText.textContent=""}showUnavailable(t="uncalibrated"){this.update({measurementState:"unavailable",calibrationState:t,environmentConfidence:"unverified",riskState:"unknown",referencePositionScore:0,trackAvailable:!1,growthReserveReady:!1,muted:!1,pendingFailureConfirmation:!1,uncertaintySources:[]})}focusPendingConfirmation(){const t=U(this.shadow,'[data-role="pending-confirm"]');t.hidden||(this.setOpen(!0),t.scrollIntoView({block:"nearest",behavior:"smooth"}),ae(this.shadow,"confirm-yes").focus({preventScroll:!0}))}showConsentCard(){this.lastRenderSignature=void 0,this.mode="consent",this.root.dataset.risk="unknown",this.statusText.textContent=s("pillConsentRequired","Consent required"),this.statusDot.dataset.risk="unknown",this.monitorPanel.hidden=!0,this.consentPanel.hidden=!1,this.setOpen(!0)}showDisabled(){this.lastRenderSignature=void 0,this.mode="disabled",this.root.dataset.risk="unknown",this.statusText.textContent=s("pillDisabled","Disabled"),this.statusDot.dataset.risk="unknown",this.monitorPanel.hidden=!0,this.consentPanel.hidden=!1,this.setOpen(!1)}destroy(){const t=globalThis;document.removeEventListener("pointerdown",this.onDocumentPointerDown,!0),document.removeEventListener("keydown",this.onDocumentKeyDown,!0),window.removeEventListener("resize",this.onWindowResize),this.toastTimer!==void 0&&window.clearTimeout(this.toastTimer),this.root.remove(),t[Ge]===this.destroyGlobalHook&&delete t[Ge]}setMenuOpen(t,n=!1,o=!1){this.menuOpen=t,this.menuPopover.hidden=!t,this.menuTrigger.setAttribute("aria-expanded",String(t)),t?(this.positionMenuPopover(),o&&this.menuItems()[0]?.focus({preventScroll:!0})):n&&this.menuTrigger.focus({preventScroll:!0})}positionMenuPopover(){const t=this.menuTrigger.getBoundingClientRect(),n=this.menuPopover.getBoundingClientRect(),o=Ga(window.innerWidth,window.innerHeight,t,{width:n.width,height:n.height});this.menuPopover.style.left=`${o.left}px`,this.menuPopover.style.top=`${o.top}px`}menuItems(){return Array.from(this.menuPopover.querySelectorAll('[role="menuitem"]:not(:disabled)'))}handleMenuKeyDown(t){if(!this.menuOpen)return;if(t.key==="Escape"){t.preventDefault(),t.stopPropagation(),this.setMenuOpen(!1,!0);return}if(t.key==="Tab"){this.setMenuOpen(!1);return}const n=this.menuItems();if(n.length===0)return;const o=Math.max(0,n.indexOf(this.shadow.activeElement));let a;t.key==="ArrowDown"&&(a=(o+1)%n.length),t.key==="ArrowUp"&&(a=(o-1+n.length)%n.length),t.key==="Home"&&(a=0),t.key==="End"&&(a=n.length-1),a!==void 0&&(t.preventDefault(),n[a]?.focus({preventScroll:!0}))}bindMenuAction(t,n){ae(this.shadow,t).addEventListener("click",()=>{this.setMenuOpen(!1),n()})}bindButton(t,n){ae(this.shadow,t).addEventListener("click",n)}}function La(e){return e.calibrationState==="calibrating"?{label:s("statusCalibrating","Calibrating")}:e.measurementState==="uncertain"||e.measurementState==="unavailable"?{label:s("statusUnknown","Unable to assess")}:e.calibrationState==="environment_unknown"?{label:s("statusEnvironmentUnknown","Unable to assess")}:e.calibrationState==="stale"?{label:s("statusStale","Recalibration needed")}:e.calibrationState==="uncalibrated"?{label:s("statusUncalibrated","Not calibrated")}:e.measurementState==="partial"?{label:s("statusUnknown","Unable to assess")}:e.riskState==="normal"?{label:s("riskNormal","Lower risk")}:e.riskState==="long"?{label:s("riskLong","Long")}:e.riskState==="organize"?{label:s("riskOrganize","Near risk")}:e.riskState==="high"?{label:s("riskHigh","High risk")}:{label:s("statusUnknown","Unable to assess")}}function Na(e){return e.calibrationState==="calibrating"?s("statusCalibratingHelp","Reading the full chat. Keep this page open."):e.measurementState!=="complete"?s("statusMeasurementUncertainHelp","This chat has not been read reliably yet. Use More to run a full read."):e.calibrationState==="environment_unknown"?s("statusEnvironmentUnknownHelp","Measurement is temporarily unavailable. Risk assessment will resume automatically."):e.calibrationState==="stale"?s("statusStaleHelp","The measurement method has changed. Recalibrate to resume risk alerts."):e.calibrationState==="uncalibrated"?s("statusUncalibratedHelp","To enable risk alerts, calibrate with a historical chat that reached the conversation-length limit."):e.calibrationState==="calibrated_conservative"?e.riskState==="high"?s("riskAdviceHighConservative","This chat is in the high-risk range. The reference is conservative, so continue in a new chat soon."):s("statusConservativeCalibration","Reference established. This chat includes content that cannot be measured precisely, so alerts will be more conservative."):e.growthReserveReady?Fa(e.riskState):s("statusGrowthLearning","Reference established. Learning chat growth; until enough samples are available, alerts trigger only at the historical reference.")}function Fa(e){return e==="normal"?s("riskAdviceNormal","This chat is in the lower-risk range."):e==="long"?s("riskAdviceLong","This chat is getting long. Consider organizing important context."):e==="organize"?s("riskAdviceOrganize","This chat is nearing the risk range. Prepare to continue in a new chat."):e==="high"?s("riskAdviceHigh","This chat is in the high-risk range. Continue in a new chat soon."):""}function Pa(){return`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      button { font-family:inherit; }
      .stack { display:flex; flex-direction:column; align-items:flex-end; gap:8px; font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; color:#171717; }
      .pill { border:1px solid rgba(0,0,0,.12); background:rgba(255,255,255,.96); backdrop-filter:blur(16px); box-shadow:0 8px 30px rgba(0,0,0,.12); border-radius:999px; padding:8px 12px; display:flex; align-items:center; gap:7px; cursor:pointer; color:#171717; font-size:13px; font-weight:600; }
      .pill:hover { background:#fff; }
      .dot { width:8px; height:8px; border-radius:50%; background:#929292; box-shadow:0 0 0 3px rgba(146,146,146,.13); }
      .dot[data-risk="normal"] { background:#22a06b; box-shadow:0 0 0 3px rgba(34,160,107,.12); }
      .dot[data-risk="long"] { background:#d69e2e; box-shadow:0 0 0 3px rgba(214,158,46,.13); }
      .dot[data-risk="organize"] { background:#e87924; box-shadow:0 0 0 3px rgba(232,121,36,.14); }
      .dot[data-risk="high"] { background:#d14343; box-shadow:0 0 0 3px rgba(209,67,67,.14); }
      .panel { width:308px; max-width:calc(100vw - 24px); max-height:min(520px,calc(100vh - 96px)); overflow:visible; border:1px solid rgba(0,0,0,.09); border-radius:12px; background:rgba(255,255,255,.985); backdrop-filter:blur(20px); box-shadow:0 16px 48px rgba(0,0,0,.14); padding:12px; font-size:12px; line-height:1.45; }
      .panel[hidden],.section[hidden],[hidden] { display:none !important; }
      .header { display:flex; align-items:center; justify-content:space-between; gap:8px; margin:0 2px 6px; }
      .title { font-size:14px; font-weight:700; }
      .menu { position:relative; flex:0 0 auto; }
      button.menu-trigger { width:28px; height:26px; border:0; background:transparent; display:grid; place-items:center; border-radius:7px; cursor:pointer; color:#727272; font-size:15px; font-weight:700; line-height:1; letter-spacing:1px; user-select:none; }
      button.menu-trigger:hover,button.menu-trigger[aria-expanded="true"] { background:#f4f4f4; color:#333; }
      button.menu-trigger:focus-visible { outline:2px solid #4c9ffe; outline-offset:1px; }
      .menu-popover { position:fixed; z-index:2147483647; width:196px; padding:4px; border:1px solid #dedede; border-radius:10px; background:#fff; box-shadow:0 10px 28px rgba(0,0,0,.16); }
      button.menu-action { width:100%; min-height:34px; border:0; background:transparent; border-radius:7px; padding:8px 10px; display:flex; align-items:center; text-align:left; color:#2f2f2f; cursor:pointer; font-size:12px; font-weight:600; line-height:1.3; }
      button.menu-action + button.menu-action { margin-top:2px; }
      button.menu-action:hover:not(:disabled),button.menu-action:focus-visible { background:#f3f3f3; color:#171717; outline:none; }
      button.menu-action:disabled { opacity:.45; cursor:not-allowed; }
      .trend { border-radius:13px; padding:10px 11px 9px; background:linear-gradient(180deg,#252527,#222224); color:#fff; box-shadow:inset 0 0 0 1px rgba(255,255,255,.045),0 7px 18px rgba(0,0,0,.09); }
      .risk-head { display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:8px; }
      .risk-head span { color:rgba(255,255,255,.68); font-size:11px; font-weight:400; }
      .risk-head strong { color:#fff; font-size:13px; font-weight:700; text-align:right; }
      .track { display:grid; grid-template-columns:repeat(16,1fr); height:16px; border-radius:999px; overflow:hidden; background:linear-gradient(90deg,#38ad70 0%,#82bf60 28%,#d8bd51 55%,#e58b49 77%,#cf5961 100%); box-shadow:inset 0 1px 2px rgba(0,0,0,.15),inset 0 0 0 1px rgba(255,255,255,.08); }
      .segment { position:relative; min-width:0; background:rgba(20,20,22,.54); border-right:1px solid rgba(20,20,22,.72); transition:background .18s ease; }
      .segment:nth-child(10),.segment:nth-child(12),.segment:nth-child(14) { border-right-width:2px; }
      .segment:last-child { border-right:0; }
      .segment[data-active="true"] { background:rgba(20,20,22,0); }
      .segment::after { content:""; position:absolute; inset:0; pointer-events:none; background:linear-gradient(180deg,rgba(255,255,255,.1),rgba(255,255,255,0) 58%,rgba(0,0,0,.025)); }
      .risk-scale { display:flex; justify-content:space-between; margin-top:5px; padding:0 1px; color:rgba(255,255,255,.56); font-size:10px; font-weight:400; }
      .risk-advice { margin:7px 1px 0; color:rgba(255,255,255,.88); font-size:11px; font-weight:400; line-height:1.45; }
      .trend[data-track-available="false"] { background:linear-gradient(180deg,#2b2c2e,#252629); }
      button.calibrate-link { width:100%; margin-top:7px; border:1px solid #e7e7e7; background:#fff; border-radius:8px; padding:8px 10px; display:flex; flex-direction:column; align-items:flex-start; justify-content:center; gap:2px; color:#2f2f2f; cursor:pointer; text-align:left; font-size:12px; font-weight:600; line-height:1.3; }
      .calibrate-help { color:#707070; font-size:11px; font-weight:400; line-height:1.35; }
      button.calibrate-link:hover:not(:disabled) { background:#f8f8f8; border-color:#dedede; }
      button.calibrate-link:disabled { opacity:.55; cursor:not-allowed; }
      .scan-notice { position:relative; margin-top:7px; padding:9px 30px 9px 10px; border:1px solid #ead7a4; border-radius:8px; background:#fffaf0; color:#4b3b18; font-size:11px; font-weight:400; line-height:1.45; }
      .scan-notice[data-tone="error"] { border-color:#e5b9b9; background:#fff5f5; color:#6b2626; }
      button.scan-notice-dismiss { position:absolute; top:5px; right:5px; width:22px; height:22px; border:0; border-radius:6px; background:transparent; color:#806f49; cursor:pointer; font-size:15px; font-weight:600; line-height:1; }
      .pending { margin-top:9px; border-radius:10px; padding:10px; background:#fff8e6; border:1px solid #f4d58d; }
      .pending strong { display:block; margin-bottom:4px; }
      .pending p { margin:0; color:#5f4a20; }
      .consent-copy { margin:0; padding-left:18px; color:#3f3f3f; }
      .consent-copy li { margin:6px 0; }
      .actions { display:grid; grid-template-columns:1fr; gap:6px; margin-top:9px; }
      button.action { min-height:32px; border:1px solid #e0e0e0; background:#fff; border-radius:8px; padding:6px 9px; font-size:12px; font-weight:600; line-height:1.3; color:#303030; cursor:pointer; text-align:center; transition:background .14s ease,border-color .14s ease,transform .08s ease; }
      button.action:hover:not(:disabled) { background:#f7f7f7; border-color:#d7d7d7; }
      button.action:active:not(:disabled) { transform:translateY(1px); }
      button.primary { min-height:34px; background:#181818; color:#fff; border-color:#181818; }
      button.primary:hover:not(:disabled) { background:#242424; border-color:#242424; }
      button.cta { width:100%; margin-top:9px; }
      .toast { max-width:308px; border-radius:8px; padding:7px 10px; background:#171717; color:#fff; font-size:11px; font-weight:600; line-height:1.35; box-shadow:0 8px 25px rgba(0,0,0,.2); }
      @keyframes guardPulse { 0%{transform:scale(1)} 40%{transform:scale(1.025)} 100%{transform:scale(1)} }
      :host(.guard-attention) .panel { animation:guardPulse .32s ease-out; }
      @media (prefers-color-scheme: dark) {
        .pill,.panel { background:rgba(35,35,35,.96); color:#f1f1f1; border-color:rgba(255,255,255,.14); }
        button.menu-trigger { color:#aaa; }
        button.menu-trigger:hover,button.menu-trigger[aria-expanded="true"] { background:#303030; color:#eee; }
        .menu-popover { background:#272727; border-color:#444; box-shadow:0 10px 28px rgba(0,0,0,.32); }
        button.menu-action { color:#f0f0f0; }
        button.menu-action:hover:not(:disabled),button.menu-action:focus-visible { background:#353535; color:#fff; }
        button.calibrate-link { background:#262626; border-color:#404040; color:#f0f0f0; }
        .calibrate-help { color:#b8b8b8; }
        .scan-notice { background:#332f25; border-color:#5a5036; color:#eadfbf; }
        .scan-notice[data-tone="error"] { background:#382828; border-color:#684242; color:#f0caca; }
        button.action { background:#2b2b2b; color:#f3f3f3; border-color:#444; }
        button.primary { background:#f1f1f1; color:#171717; border-color:#f1f1f1; }
      }
    </style>
    <div class="stack">
      <div class="toast" data-role="toast" hidden></div>
      <div class="panel" data-role="panel" hidden>
        <div class="section" data-role="monitor-panel">
          <div class="header">
            <div class="title">LongChat Guard</div>
            <div class="menu">
              <button class="menu-trigger" type="button" data-role="menu-trigger" aria-label="${s("menuMore","More")}" aria-haspopup="menu" aria-expanded="false">···</button>
            </div>
          </div>
          <div class="trend" data-role="trend" data-track-available="false">
            <div class="risk-head"><span data-value="card-caption">${s("labelStatus","Status")}</span><strong data-value="card-status">${s("statusUncalibrated","Not calibrated")}</strong></div>
            <div class="track" data-role="risk-track" hidden>${Ia()}</div>
            <div class="risk-scale" data-role="risk-scale" hidden><span>${s("labelLowRisk","Low risk")}</span><span>${s("labelHighRisk","High risk")}</span></div>
            <p class="risk-advice" data-role="risk-advice"></p>
          </div>
          <button class="calibrate-link" data-action="calibrate" hidden>
            <span data-value="calibrate-label">${s("actionCalibrateThisChat","Calibrate with this chat")}</span>
            <span class="calibrate-help">${s("actionCalibrateThisChatHelp","Only use a historical chat you know reached the conversation-length limit.")}</span>
          </button>
          <div class="scan-notice" data-role="scan-notice" role="status" aria-live="polite" hidden>
            <div data-role="scan-notice-text"></div>
            <button class="scan-notice-dismiss" type="button" data-action="scan-notice-dismiss" aria-label="${s("actionDismiss","Dismiss")}">×</button>
          </div>
          <div class="pending" data-role="pending-confirm" hidden>
            <strong>${s("passiveLimitQuestion","Possible conversation-length limit detected")}</strong>
            <p>${s("passiveLimitHelp","Use this chat as a calibration sample only if you know this was the conversation-length limit.")}</p>
            <div class="actions">
              <button class="action primary" data-action="confirm-yes">${s("passiveLimitYes","Use this chat to calibrate")}</button>
              <button class="action" data-action="confirm-no">${s("passiveLimitNo","Ignore")}</button>
            </div>
          </div>
          <button class="action primary cta" data-action="copy" hidden>${s("actionCopyContinuation","Copy continuation prompt")}</button>
        </div>
        <div class="section" data-role="consent-panel" hidden>
          <div class="title">${s("consentTitle","Enable local long-chat alerts")}</div>
          <ul class="consent-copy">
            <li>${s("consentLocalRead",be[0])}</li>
            <li>${s("consentAutoWheel","Full reads temporarily use browser debugging to scroll the current ChatGPT tab. Debugging ends when the read stops.")}</li>
            <li>${s("consentNoUpload",be[1])}</li>
            <li>${s("consentNoRawPersist",be[2])}</li>
            <li>${s("consentDeleteLocal",be[3])}</li>
          </ul>
          <div class="actions">
            <button class="action primary" data-action="consent-accept">${s("consentAccept",be[4])}</button>
            <button class="action" data-action="consent-decline">${s("consentDecline",be[5])}</button>
          </div>
        </div>
      </div>
      <div class="menu-popover" data-role="menu-popover" role="menu" aria-label="${s("menuMore","More")}" hidden>
        <button class="menu-action" type="button" role="menuitem" tabindex="-1" data-action="measure-current"><span data-value="measure-current-label">${s("actionMeasureCurrentChat","Read full current chat")}</span></button>
        <button class="menu-action" type="button" role="menuitem" tabindex="-1" data-action="relearn">${s("actionRecalibrate","Recalibrate alert reference")}</button>
        <button class="menu-action" type="button" role="menuitem" tabindex="-1" data-action="mute"><span data-value="mute-label">${s("actionMute","Mute this chat")}</span></button>
      </div>
      <button class="pill" data-role="pill" aria-expanded="false" aria-label="${s("pillAria","Open LongChat Guard")}">
        <span class="dot" data-role="status-dot"></span>
        <span data-role="status-text">${s("statusUncalibrated","Not calibrated")}</span>
      </button>
    </div>
  `}function Ia(){return Array.from({length:16},(e,t)=>`<span class="segment" data-risk-segment data-active="false" aria-hidden="true" data-segment="${t+1}"></span>`).join("")}function Da(e){return Number.isFinite(e)?Math.max(0,Math.min(100,e)):0}function Ua(e){const t=Da(e);return t<=0?0:Math.min(16,Math.max(1,Math.floor(t/6.25)))}function Oa(e){const t=e.calibrationState==="calibrated"||e.calibrationState==="calibrated_conservative",n=e.riskState!=="unknown"||e.environmentConfidence==="unverified";return e.trackAvailable&&e.measurementState==="complete"&&t&&n}function Ga(e,t,n,o){const r=Math.min(Math.max(n.right-o.width,8),Math.max(8,e-o.width-8)),l=n.top-o.height-8,S=n.bottom+8,b=l>=8?l:Math.min(Math.max(S,8),Math.max(8,t-o.height-8));return{left:r,top:b}}function Ba(e,t){return!e.includes(t)}function za(e){return e==="Escape"}function Te(e,t,n){U(e,`[data-value="${t}"]`).textContent=n}function ae(e,t){return U(e,`[data-action="${t}"]`)}function U(e,t){const n=e.querySelector(t);if(!n)throw new Error(`missing_ui_element:${t}`);return n}const ct=new xn,Be="longChatGuardRecentBlankStartAt";function Ka(){return s("continuationPrompt","Create a continuation package for a new ChatGPT chat so work can resume without re-analysis. Preserve the current goal and exact stage, completed work, confirmed decisions, constraints and user preferences, key files/paths/repos/commits/code/config/data/platform state, unresolved issues and failed attempts, prioritized next actions, risks and pitfalls, and essential exact wording when needed. Clearly separate confirmed facts from inference and items still needing verification. If code or files are involved, state what was changed, tested, committed, pushed or published, and what remains pending. Finish with a short instruction telling the new chat to continue from the listed next action instead of starting over.")}async function qa(){if(location.hostname!=="chatgpt.com")return;let t=(await q({type:"guard.loadState"})).state;const n=new kt(t.installSalt),o=c=>pn(c,t.installSalt);let a,i,r,l=Hn(),S=!1,b=!1,v,f=!1,u,g,N=Date.now(),y=new De;const z=new _a,V=()=>a?.(),F=()=>t.generations.find(c=>c.id===t.settings.generationId)??t.generations[0],O=()=>xe({generation:F(),currentEnvironment:ce(document),calibrating:b}),oe=c=>{T.update(c)},I=c=>{T.showUnavailable(c)},K=()=>{const c=r;if(!c){I(O());return}const d=F(),m=t.ledgers[c];if(!d||!m){I(O());return}const $=$t({supported:m.generationId===d.id,ledger:m}),p=ce(document),A=xe({generation:d,currentEnvironment:p,calibrating:b}),M=xt(d.environmentSignature,p),k=ke(d),B=ct.estimate(et(document)),G=Tt({currentLoad:m.currentEstimatedLoad,composerDraftLoad:B,measurementState:$,calibrationState:A,environmentConfidence:M,...k.failureReference?{failureReference:k.failureReference}:{},...k.growthReserveReady?{growthReserve:k.growthReserve}:{}}),ne=t.conversationControls[c]??{};oe({conversationKey:c,measurementState:$,calibrationState:A,environmentConfidence:M,riskState:G.state,referencePositionScore:G.referencePositionScore,trackAvailable:Je($)&&Xe(A),growthReserveReady:k.growthReserveReady,muted:ne.muted??!1,pendingFailureConfirmation:d.pendingFailureConfirmations.some(ye=>ye.conversationKey===c),uncertaintySources:m.uncertaintySources})},le=c=>{if(!c)return!1;const d=F(),m=t.ledgers[c];return!d||!m||!Ze({ledger:m,generationId:d.id,environmentSignature:ce(document)})?!1:(r=c,K(),!0)},x=async(c,d)=>{try{return t=(await c()).state,T.showToast(d),V(),!0}catch{return T.showToast(s("toastActionFailed","Action failed. Please try again.")),!1}},D=async c=>{const d=Date.now(),m=[];for(const[$,p]of c.entries()){const A=await n.fingerprint(`${p.role}${p.text}`),M=p.stableHint?await n.fingerprint(`stable${p.stableHint}`):void 0,k={contentFingerprint:A,role:p.role,tokenEstimate:ct.estimate(p.text),charCount:p.text.length,observedAt:d,ordinalHint:$,hasCode:p.hasCode,attachmentCount:p.attachmentCount};M&&(k.stableHintHash=M),m.push(k)}return m},te=async(c,d)=>{if(c.length===0||d.messages.length===0)return!1;const m=new Set(d.activeFingerprints),$=d.messages.filter(p=>m.size===0||m.has(p.fingerprint));for(const p of c){if(p.role==="unknown"||!p.text.trim())continue;const A=await n.fingerprint(`${p.role}${p.text}`),M=p.stableHint?await n.fingerprint(`stable${p.stableHint}`):void 0;if($.some(k=>k.role===p.role&&(k.contentFingerprint===A||M!==void 0&&k.stableHintHash===M)))return!0}return!1},T=new Ea({onCopyContinuation:()=>{eo(Ka()).then(()=>T.showToast(s("toastContinuationCopied","Continuation prompt copied"))).catch(()=>T.showToast(s("toastCopyFailed","Copy failed. Please try again.")))},onCalibrate:()=>{ut()},onMeasureCurrentChat:()=>{qe()},onRecalibrate:()=>{b||f||x(()=>q({type:"guard.startGeneration",reason:"recalibrate",observedAt:Date.now()}),s("toastRecalibrationStarted","Previous reference kept as an outdated prior. Calibrate again before relying on risk levels."))},onToggleMute:()=>{const c=r;if(!c)return;const d=t.conversationControls[c]??{};x(()=>q({type:"guard.updateControl",conversationKey:c,patch:{muted:!d.muted}}),d.muted?s("toastRemindersRestored","Alerts restored for this chat"):s("toastConversationMuted","Alerts muted for this chat"))},onConfirmFailure:c=>{const d=r;d&&x(()=>q({type:"guard.confirmPendingFailure",conversationKey:d,accepted:c,observedAt:Date.now()}),c?s("toastFailureLearned","Calibration evidence saved from this limit event."):s("toastFailureIgnored","This event was ignored."))},onAcceptPrivacyConsent:()=>{x(()=>q({type:"guard.updatePrivacyConsent",accepted:!0,observedAt:Date.now()}),s("toastMonitoringEnabled","Local long-chat alerts enabled")).then(c=>{c&&X()})},onDeclinePrivacyConsent:()=>{x(()=>q({type:"guard.updatePrivacyConsent",accepted:!1,observedAt:Date.now()}),s("toastMonitoringDeferred","Not enabled")).then(c=>{c&&T.showDisabled()})}}),j=()=>{if(!Z(location.href))return;const c=Date.now(),d=En(l,!!r,c);d.resetPreviousBinding&&(l=d.state,r=void 0,g=void 0,y=new De,z.reset(),Ke(),ze(c))},Me=async()=>{if(!(b||f))try{j();const c=location.href,d=()=>location.href===c?!0:(window.setTimeout(()=>a?.(),0),!1),m=pe(document,location.href,"none"),$=ce(document),p=l.activeConversationId,A=re(location.href),M=je(m),k=Z(location.href)?void 0:Nn({activeConversationId:p,routeConversationId:A,observedConversationId:M}),B=p?await o(`chatgpt:${p}`):void 0,G=B?t.ledgers[B]:void 0,ne=!!(p&&k&&p!==k),ye=!!(g?.conversationKey&&g.conversationKey===B&&Date.now()-g.capturedAt>=0&&Date.now()-g.capturedAt<=me),He=!!(ne&&ye&&p&&l.observedFromStartConversationId===p&&G&&await te(m.messages,G)),ht=Z(location.href)||!k&&m.messages.length===0,gt=k??l.activeConversationId,de=gt?await o(`chatgpt:${gt}`):void 0,en=de?t.ledgers[de]:void 0,tn=Ze({ledger:en,generationId:t.settings.generationId,environmentSignature:$});let mt=!1;if(!!(k&&!tn&&!l.pendingNewChatStartedAt&&!l.blankSurfaceObserved&&!He&&m.tailEvidence==="at_tail"&&m.messages.length>=2)&&k&&de){const _=await D(m.messages),Y=Ma({observed:_,currentConversationKey:de,ledgers:t.ledgers,generationId:t.settings.generationId,environmentSignature:$,atTail:!0});mt=z.observe({newConversationId:k,...Y?{sourceKey:Y}:{},messageFingerprints:_.map(cn=>cn.contentFingerprint),observedAt:Date.now()}),Y&&!mt&&window.setTimeout(()=>a?.(),950)}else z.reset();if(!d())return;const nn=Date.now(),Ee=Fn(l,{conversationId:k,isBlankSurface:ht,messageCount:m.messages.length,hasUserMessage:m.messages.some(_=>_.role==="user"),persistedAuthoritative:tn,sameConversationEvidence:He,verifiedInheritedPrefix:mt,bridgedNewChatStartedAt:Za(nn),now:nn});l=Ee.state,m.coverageEvidence=Ee.coverageEvidence,Ee.consumedBridgedStart&&Ke();const to=Ee.activeConversationId?await o(`chatgpt:${Ee.activeConversationId}`):void 0,J=$e(m),no=Ut(J.messages),P=J.conversationKey?await o(J.conversationKey):to;if(!P||J.health==="unreliable"||!no){if(le(P))return;r=P,I(xe({generation:F(),currentEnvironment:$}));return}if(P!==r){const _=!!(He&&B&&B===r),Y=g;_&&Y&&Y.conversationKey===B?g={...Y,conversationKey:P}:Y?.conversationKey&&Y.conversationKey!==P&&(g=void 0),r=P,_||(y=new De)}const pt=t.ledgers[P],ft=await D(J.messages),ue=Date.now(),an=ft.filter(_=>_.role==="user"&&!pt?.messages.some(Y=>_.stableHintHash&&Y.stableHintHash===_.stableHintHash||!_.stableHintHash&&Y.contentFingerprint===_.contentFingerprint&&Y.role==="user")).length,bt=ct.estimate(J.composerText),ao=dt([...Ot(document),...ft.some(_=>(_.attachmentCount??0)>0)?["attachment"]:[]]);if(!d())return;N=Math.max(N+1,ue);let ie=await q({type:"guard.observeWindow",window:{conversationKey:P,coverageState:J.coverageState,parserHealth:J.health,tailEvidence:J.tailEvidence,observedMessages:ft,composerTokenEstimate:bt,environmentSignature:$,uncertaintySources:ao,expectedGenerationId:t.settings.generationId,baseRevision:pt?.ledgerRevision??0,observationEpoch:N,observedAt:ue}});if(t=ie.state,!d())return;if(ie.staleObservation){window.setTimeout(()=>a?.(),50);return}let Le=ie.risk,W=ie.snapshot;if(W||(W=t.ledgers[P]),!W)throw new Error("missing_persisted_snapshot");if(g&&an>0&&ie.observationDisposition==="committed"){const _=pt?.ledgerRevision??0;g=(!g.conversationKey||g.conversationKey===P)&&g.generationId===W.generationId&&g.ledgerRevision===_&&an===1?{...g,conversationKey:P,accepted:!0}:void 0}for(const _ of J.visibleErrors)Wt({errorKind:_.kind,confidence:_.confidence,turn:g,conversationKey:P,generationId:W.generationId,observedAt:ue})&&(ie=await q({type:"guard.recordFailure",event:{conversationKey:P,errorKind:_.kind,confidence:_.confidence,composerTokenEstimate:bt,expectedGenerationId:W.generationId,expectedLedgerRevision:W.ledgerRevision,observedAt:ue}}),t=ie.state,Le=ie.risk??Le);W=t.ledgers[P]??W;const oo=W.activeFingerprints.at(-1),se=W.messages.find(_=>_.fingerprint===oo),io=J.visibleErrors.some(_=>Wt({errorKind:_.kind,confidence:_.confidence,turn:g,conversationKey:P,generationId:W.generationId,observedAt:ue})),Ne=y.observe({observedAt:ue,generationState:J.generationState,hasLengthError:io,...se?.fingerprint?{assistantFingerprint:se.fingerprint}:{},...se?.role?{role:se.role}:{},...se?.contentFingerprint?{contentFingerprint:se.contentFingerprint}:{},...se?.tokenEstimate!==void 0?{tokenEstimate:se.tokenEstimate}:{}});if(Ne.state==="completed"&&g?.accepted){const _=await q({type:"guard.recordCompletion",event:{conversationKey:P,assistantFingerprint:Ne.candidate.assistantFingerprint,beforeTurnLoad:g.load,expectedGenerationId:W.generationId,expectedLedgerRevision:W.ledgerRevision,observedAt:ue}});t=_.state,Le=_.risk??Le,g=void 0}else Ne.state==="pending"&&Ne.candidate&&Ne.reason==="stability_window_open"&&window.setTimeout(()=>a?.(),At+50);const Ce=F(),he=t.ledgers[P];if(!Ce||!he){I(O());return}const vt=$t({supported:he.generationId===Ce.id,ledger:he}),wt=xe({generation:Ce,currentEnvironment:he.environmentSignature}),on=xt(Ce.environmentSignature,he.environmentSignature),Fe=ke(Ce),We=Le??Tt({currentLoad:he.currentEstimatedLoad,composerDraftLoad:bt,measurementState:vt,calibrationState:wt,environmentConfidence:on,...Fe.failureReference?{failureReference:Fe.failureReference}:{},...Fe.growthReserveReady?{growthReserve:Fe.growthReserve}:{}}),St=t.conversationControls[P]??{},sn=An({state:We.state,control:St});sn&&(t=(await q({type:"guard.updateControl",conversationKey:P,patch:Mn(St,We.state)})).state);const so=t.conversationControls[P]??St,rn=Ce.pendingFailureConfirmations.some(_=>_.conversationKey===P);if(!d())return;oe({conversationKey:P,measurementState:vt,calibrationState:wt,environmentConfidence:on,riskState:We.state,referencePositionScore:We.referencePositionScore,trackAvailable:Je(vt)&&Xe(wt),growthReserveReady:Fe.growthReserveReady,muted:so.muted??!1,pendingFailureConfirmation:rn,uncertaintySources:he.uncertaintySources}),rn?T.focusPendingConfirmation():sn&&T.drawAttention()}catch{j();const d=Ae(location.href)??(l.activeConversationId?`chatgpt:${l.activeConversationId}`:void 0),m=d?await o(d):r;if(le(m))return;I(O())}},_e=async c=>{const d=new AbortController;c.controller=d;const m=p=>{d.signal.aborted||(c.cancelReason=p,d.abort())},$=()=>({complete:!1,reason:"scan_limit_reached",observedMessages:[],messageCount:0,attachmentCount:0,unknownRoleCount:0,uncertaintySources:[],diagnostics:[]});try{return c.shield=Ra(m),await wa(d.signal,()=>va(d.signal,p=>{c.shield?.setStage(p==="done"?"verify":p)}),()=>aa(document,D),()=>c.shield?.setStage("verify"))}catch(p){if(d.signal.aborted)return $();throw p}};async function qe(){if(b||f)return;const c=pe(document,location.href,"none"),m=$e(c).conversationKey??Ae(location.href);if(!m){T.showScanNotice(s("measurementNoConversation","Open the chat you want to measure, then try again."),"warning");return}const $=await o(m),p={id:Qt(),rawConversationKey:m,persistedConversationKey:$,expectedGenerationId:t.settings.generationId,expectedLedgerRevision:t.ledgers[$]?.ledgerRevision??0},A={};u=p,f=!0,T.setMeasurementBusy(!0);try{const M=await _e(A);if(A.controller?.signal.aborted){T.showScanNotice(s("autoShieldCancelledNotice","Automatic reading was stopped. No unfinished result was saved."),"warning");return}if(!Se(p))throw new Error("scan_session_replaced");if((Ae(location.href)??$e(pe(document,location.href,"none")).conversationKey)!==p.rawConversationKey)throw new Error("conversation_changed_during_scan");if(!M.complete){T.showScanNotice(s("measurementScanIncomplete","The full chat could not be read, so this chat's risk was not updated. Keep the page open and try again."),"warning");return}if(M.unknownRoleCount>0){T.showScanNotice(s("measurementParserFailed","This chat could not be measured reliably because some message roles could not be read."),"error");return}const B=dt([...M.uncertaintySources,...M.attachmentCount>0?["attachment"]:[]]);if(A.controller?.signal.aborted)return;A.shield?.setStage("save"),t=(await q({type:"guard.commitMeasurementScan",event:{conversationKey:p.rawConversationKey,expectedGenerationId:p.expectedGenerationId,expectedLedgerRevision:p.expectedLedgerRevision,environmentSignature:ce(document),uncertaintySources:B,observedMessages:M.observedMessages,observedAt:Date.now()}})).state,T.showToast(s("measurementScanSuccess","Full chat read complete. LongChat Guard can now assess this chat using your existing alert reference."),4200)}catch(M){const k=M instanceof Error?M.message:"unknown_error";T.showScanNotice(jt(k)??Wa(k),"error")}finally{A.shield?.close(),Se(p)&&(u=void 0),f=!1,T.setMeasurementBusy(!1),V()}}async function ut(){if(b)return;const c=pe(document,location.href,"none"),d=$e(c),m=d.conversationKey??Ae(location.href);if(!m){T.showScanNotice(s("calibrationNoConversation","Open the historical chat you know reached the conversation-length limit, then try again."),"warning");return}if(d.health!=="healthy"||!Ut(d.messages)){T.showScanNotice(s("calibrationParserFailed","Calibration was not saved because message roles could not be read reliably."),"error");return}const $=ce(document);yn({generation:F(),currentEnvironment:$})&&(t=(await q({type:"guard.startGeneration",reason:"environment_change",observedAt:Date.now()})).state);const p=await o(m),A=t.settings.generationId,M=t.ledgers[p]?.ledgerRevision??0,k={id:Qt(),rawConversationKey:m,persistedConversationKey:p,expectedGenerationId:A,expectedLedgerRevision:M},B={};v=k,b=!0,T.setCalibrationBusy(!0);try{const G=await _e(B);if(B.controller?.signal.aborted){T.showScanNotice(s("autoShieldCancelledNotice","Automatic reading was stopped. No unfinished result was saved."),"warning");return}if(!we(k))throw new Error("scan_session_replaced");if((Ae(location.href)??$e(pe(document,location.href,"none")).conversationKey)!==k.rawConversationKey)throw new Error("conversation_changed_during_scan");if(!G.complete){T.showScanNotice(Va(G.reason),"warning");return}if(G.unknownRoleCount>0){T.showScanNotice(s("calibrationParserFailed","Calibration was not saved because message roles could not be read reliably."),"error");return}const ye=dt([...G.uncertaintySources,...G.attachmentCount>0?["attachment"]:[]]),He=ce(document),ht=Date.now();if(B.controller?.signal.aborted)return;B.shield?.setStage("save"),t=(await q({type:"guard.commitCalibration",event:{conversationKey:k.rawConversationKey,expectedGenerationId:k.expectedGenerationId,expectedLedgerRevision:k.expectedLedgerRevision,scanSessionId:k.id,environmentSignature:He,uncertaintySources:ye,observedMessages:G.observedMessages,observedAt:ht}})).state;const de=F();(de?ke(de):void 0)?.failureReference?.quality==="conservative"&&ye.length>0?T.showScanNotice(s("calibrationConservativeSuccess","Reference established. This chat includes files, tools, or other context that cannot be measured precisely, so alerts will be more conservative."),"warning"):T.showToast(s("calibrationSuccess","Calibration complete. The local failure reference is established."),4200)}catch(G){const ne=G instanceof Error?G.message:"unknown_error";T.showScanNotice(jt(ne)??Ya(ne),"error")}finally{B.shield?.close(),we(k)&&(v=void 0),b=!1,T.setCalibrationBusy(!1),V()}}const C=(c,d)=>{d!=="local"||!c.conversationGuardState||b||f||q({type:"guard.readState"}).then(m=>{t=m.state,j(),K()}).catch(()=>{})},h=c=>{if(!Zt(c))return!1;j();const d=pe(document,location.href,"none");if(!(d.composerText??"").trim())return!1;const m=tt(document).some(ne=>Ye(ne).kind==="conversation_length_limit"),$=Date.now();if(g&&$-g.capturedAt<750)return g={...g,submitted:!0,capturedAt:$,lengthErrorVisibleAtStart:g.lengthErrorVisibleAtStart===!0||m},!0;const p=t.settings.generationId,A=r,M=A?t.ledgers[A]:void 0;if(A&&M)return g={conversationKey:A,generationId:p,ledgerRevision:M.ledgerRevision,load:M.currentEstimatedLoad,accepted:!1,capturedAt:$,submitted:!0,lengthErrorVisibleAtStart:m},!0;const k=je(d),B=l.pendingNewChatStartedAt!==void 0&&$-l.pendingNewChatStartedAt>=0&&$-l.pendingNewChatStartedAt<=me,G=!!(k&&!M&&d.messages.length===0);return(d.messages.length===0||Z(location.href)&&!k&&!M)&&(Z(location.href)||!k||l.blankSurfaceObserved===!0||B||G)?(l=Ue(l,$),ze($),r=void 0,g={generationId:p,ledgerRevision:0,load:0,accepted:!1,capturedAt:$,submitted:!0,lengthErrorVisibleAtStart:m},!0):!1},R=c=>{h(c.target)},w=()=>{l=Et(),Ke(),r=void 0,g=void 0,y=new De},H=()=>{w();const c=Date.now();l=Ue(l,c),ze(c)},L=()=>{const c=Date.now(),d=l.pendingNewChatStartedAt;d!==void 0&&c>=d&&c-d<=me&&g&&!g.conversationKey||w(),a?.()},E=c=>{const d=c.target instanceof Element?c.target:null;if(Yt(d)){g=void 0,Ke(),z.reset();return}const m=d?.closest("a[href]");let $=!1;m&&ja(m.href)&&(Z(m.href)?(H(),$=!0):w());const p=d?.closest('button, [role="button"]');!$&&p&&Qa(p)&&H();const A=d?.closest('button, [role="button"]');A&&(A instanceof HTMLButtonElement&&A.disabled||A.getAttribute("aria-disabled")!=="true"&&h(A))},Q=c=>{c.key!=="Enter"||c.shiftKey||c.isComposing||h(c.target)},Ve=()=>{j();const c=r,d=!!(c&&t.ledgers[c]);if(d)return;const m=Date.now();if(!!(g&&!g.conversationKey&&l.pendingNewChatStartedAt!==void 0&&m-l.pendingNewChatStartedAt>=0&&m-l.pendingNewChatStartedAt<=me))return;const p=!!et(document).trim(),A=Z(location.href)?0:Dn(document)?1:0;Ln({messageCount:A,composerHasText:p,hasPersistedLedger:d})&&(l=Ue(l,m),ze(m),g||(g={generationId:t.settings.generationId,ledgerRevision:0,load:0,accepted:!1,capturedAt:m,lengthErrorVisibleAtStart:tt(document).some(M=>Ye(M).kind==="conversation_length_limit")}))},ve=c=>{Zt(c.target)&&(Ve(),i?.schedule())};function X(){if(S)return;if(!Xt(t.settings)){T.showConsentCard();return}S=!0,a=_n(Me),i=Ht(K,160),document.addEventListener("submit",R,!0),document.addEventListener("click",E,!0),document.addEventListener("keydown",Q,!0),document.addEventListener("input",ve,!0);const c=window.navigation,d=()=>{a?.()};c?.addEventListener("currententrychange",d),c?.addEventListener("navigatesuccess",d),window.addEventListener("popstate",L),chrome.storage.onChanged.addListener(C);const m=Ht(()=>a?.(),180),$=new MutationObserver(p=>{Ja(p)&&m.schedule()});$.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0}),window.addEventListener("beforeunload",()=>{v=void 0,u=void 0,$.disconnect(),m.cancel(),i?.cancel(),i=void 0,document.removeEventListener("submit",R,!0),document.removeEventListener("click",E,!0),document.removeEventListener("keydown",Q,!0),document.removeEventListener("input",ve,!0),window.removeEventListener("popstate",L),c?.removeEventListener("currententrychange",d),c?.removeEventListener("navigatesuccess",d),chrome.storage.onChanged.removeListener(C),T.destroy()},{once:!0}),a()}Xt(t.settings)?X():Tn(t.settings)?T.showDisabled():T.showConsentCard();function we(c){return v?.id===c.id}function Se(c){return u?.id===c.id}}function Va(e){return e==="no_scroll_container"?s("scanNoScroll","Conversation scroll area was not found. Refresh and try again."):e==="no_messages"?s("scanNoMessages","No conversation messages are available yet. Wait for the page to finish loading."):e==="head_not_stable"?s("scanHeadLoading","Older history did not finish stabilizing, so calibration was not saved. Keep the page open and try again."):e==="tail_not_stable"?s("scanTailChanging","The end of the conversation is still changing. Calibration was not saved."):e==="window_alignment_failed"?s("scanAlignmentFailed","Part of the history could not be read continuously, so calibration was stopped instead of guessing."):e==="scan_limit_reached"?s("scanLimitReached","This chat is very long and the full history could not be confirmed. Calibration was not saved."):s("scanIncomplete","Complete history was not confirmed, so calibration was not saved.")}function jt(e){if(e.startsWith("auto_scroll_")||e.startsWith("debug_scroll_")||e==="conversation_changed"||e==="invalid_scroll_coordinates")return s("autoReadRetryHelp","Automatic reading could not finish. Keep this ChatGPT tab active and retry. Nothing incomplete was saved.")}function Wa(e){return e==="conversation_changed_during_scan"||e==="ledger_changed_during_scan"?s("measurementConversationChanged","The chat changed while it was being read. Nothing was updated; keep this chat open and try again."):e==="generation_changed_during_scan"?s("measurementGenerationChanged","The alert reference changed while this chat was being read. Nothing was updated; try again."):e==="measurement_parser_unreliable"||e==="measurement_scan_empty"?s("measurementSampleUnusable","This chat could not be measured reliably enough to determine its current risk."):s("measurementScanFailed","The full chat could not be read, so this chat's risk was not updated.")}function Ya(e){return e==="conversation_changed_during_scan"||e==="ledger_changed_during_scan"?s("calibrationConversationChanged","The conversation changed while it was being scanned. Nothing was calibrated; keep this chat open and try again."):e==="generation_changed_during_scan"?s("calibrationGenerationChanged","The alert reference changed while scanning. Nothing was calibrated; try again."):e==="calibration_parser_unreliable"||e==="calibration_scan_empty"?s("calibrationSampleUnusable","This chat could not be measured reliably enough to use as a calibration sample."):s("toastScanFailed","Calibration did not finish. No failure reference was saved.")}function Ae(e){const t=re(e);return t?`chatgpt:${t}`:void 0}function Qt(){return typeof crypto.randomUUID=="function"?crypto.randomUUID():`scan-${Date.now()}-${Math.random().toString(36).slice(2)}`}function Xt(e){return Mt({...e})}function ja(e){try{const t=new URL(e,location.href);return t.hostname!=="chatgpt.com"?!1:!!(re(t.href)||Z(t.href))}catch{return!1}}function Qa(e){if(Yt(e))return!1;const t=`${e.getAttribute("data-testid")??""} ${e.getAttribute("aria-label")??""} ${e.getAttribute("title")??""} ${e.textContent??""}`;return/new[-_ ]?chat|new conversation|新建聊天|新聊天|新的聊天|新建对话|新建對話|新增聊天|新增對話|開始新聊天|开始新聊天/i.test(t)}const lt='main, [role="main"], [role="alert"], [data-testid*="toast"], [data-testid="model-switcher-dropdown-button"]',Xa='#prompt-textarea, [data-testid="prompt-textarea"], [data-testid="chat-input"], div.ProseMirror[contenteditable="true"], div.ProseMirror[contenteditable="plaintext-only"]';function Ja(e){return e.some(t=>{const n=Jt(t.target);if(n?.closest(Xa))return!1;if(n?.closest(lt))return!0;for(const o of[...Array.from(t.addedNodes),...Array.from(t.removedNodes)]){const a=Jt(o);if(a&&(a.matches(lt)||a.querySelector(lt)))return!0}return!1})}function Jt(e){return e instanceof Element?e:e.parentElement}function Zt(e){const t=e instanceof Element?e:null;if(!t)return!1;const n=It(document);if(!n)return!1;if(t===n||n.contains(t)||t.contains(n))return!0;const o=t.closest("form");if(o&&o.contains(n))return!0;let a=n.parentElement;for(let i=0;i<4&&a;i+=1){if(a!==document.body&&a!==document.documentElement&&a.contains(t))return!0;a=a.parentElement}return!1}function ze(e){try{window.sessionStorage.setItem(Be,String(Math.max(0,Math.floor(e))))}catch{}}function Za(e){try{const t=window.sessionStorage.getItem(Be);if(!t)return;const n=Number(t),o=e-n;if(!Number.isFinite(n)||o<0||o>me){window.sessionStorage.removeItem(Be);return}return n}catch{return}}function Ke(){try{window.sessionStorage.removeItem(Be)}catch{}}function dt(e){return Array.from(new Set(e))}async function q(e){const t=await chrome.runtime.sendMessage(e);if(!t.ok)throw new Error(t.error);return t}async function eo(e){if(!navigator.clipboard?.writeText)throw new Error("clipboard_unavailable");await navigator.clipboard.writeText(e)}qa()})();
